package com.flashlab.connect;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Build;
import android.os.LocaleList;
import android.os.UserManager;
import java.util.Locale;

/** Select French once on upgrade; never reset projection or audio preferences. */
public final class FrenchDefaults {
    private FrenchDefaults() {}

    @SuppressWarnings("deprecation")
    public static void apply(Context context) {
        UserManager users = context.getSystemService(UserManager.class);
        if (users != null && !users.isUserUnlocked()) return;
        SharedPreferences migration = context.getSharedPreferences("flash_connect_language", 0);
        SharedPreferences auto = context.getSharedPreferences("settings", 0);
        SharedPreferences carplay = context.getSharedPreferences("diplay", 0);
        if (!migration.getBoolean("french-default-v1", false)) {
            auto.edit().putString("app-language", "fr").apply();
            carplay.edit().putString("app_language", "fr").apply();
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    Object manager = context.getSystemService("locale");
                    if (manager != null) manager.getClass()
                        .getMethod("setApplicationLocales", LocaleList.class)
                        .invoke(manager, new LocaleList(Locale.FRENCH));
                } catch (ReflectiveOperationException ignored) {
                    // Existing AppLocale.wrap can migrate the saved locale on Android 13+.
                    carplay.edit().putBoolean("app_language_platform_migrated", false).apply();
                }
            }
            migration.edit().putBoolean("french-default-v1", true).apply();
        }
        if ("fr".equals(auto.getString("app-language", "")) ||
                "fr".equals(carplay.getString("app_language", ""))) {
            Configuration config = new Configuration(context.getResources().getConfiguration());
            config.setLocale(Locale.FRENCH);
            config.setLayoutDirection(Locale.FRENCH);
            context.getResources().updateConfiguration(config, context.getResources().getDisplayMetrics());
        }
    }
}
