# Flash Connect 1.2.2-test — Android Auto menu

The Android Auto launch menu now has an opaque black background, dark tiles with
gold outlines, and gold Self Mode, USB and Wi-Fi icons and labels. The Settings
tile and label are hidden in landscape and portrait. The landscape chain has
three tiles; portrait retains two tiles on the first row with Wi-Fi centered
below them. Settings remain accessible through Réglages Android Auto and
Réglages CarPlay on the main Flash Connect home page.

The theme refresh methods retain gold icons and readable labels in both light
and dark configurations. Existing preferences, connection methods, automatic
reconnection, projection, audio routing and buffer defaults are unchanged.

Package: com.flashlab.connect. Version name: 1.2.2-test. Version code: 5.
The distributed APK uses the same signing certificate as 1.2.1-test.

Validation: APK resource compilation, alignment and v2/v3 signature verification
passed. The release preserves 23 DEX files and every original asset and native
library byte-for-byte. In classes14.dex, only four colour constants in three
HomeFragment UI methods differ; all other 573 classes are unchanged after
disassembly. Both compiled menu layouts were checked for a black background,
gold icons and hidden Settings views. The main home page is unchanged.

The AGENTS.md CI command was attempted but could not download Gradle 9.5.0:
java.net.SocketException: Network is unreachable. Full unit/lint/build checks
and a physical Coolray installation were not completed in this environment.

This source package contains no signing keys or accessory authentication
credentials. Existing license notices are retained.
