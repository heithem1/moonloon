# Flash Connect 1.2.3-test — interface française

Version code 6, package `com.flashlab.connect`.

Cette version ajoute les traductions françaises des 1 452 ressources de texte
propres à l’application, soit 1 395 textes uniques partagés entre Android Auto,
CarPlay et l’accueil. Les listes de thèmes, méthodes sans fil, microphones et
orientations sont traduites sans changer l’ordre ni la valeur des choix.
Les libellés intégrés au code pour la latence audio, la recherche Bluetooth,
la taille CarPlay et les messages courts sont aussi traduits.

Au premier lancement après cette mise à jour, `FrenchDefaults` sélectionne
le français pour les deux moteurs. Il ne modifie que les préférences de langue
et son marqueur de migration ; téléphones, réseau, reconnexion, routage audio,
latence et tampons restent enregistrés. Les futurs choix de langue sont conservés.
La migration attend le déverrouillage si le stockage utilisateur est verrouillé.
Le français apparaît aussi dans le sélecteur CarPlay et la liste système.

Le menu noir et or de 1.2.2 reste identique. Les réglages restent accessibles
depuis l’accueil Flash Connect. Les bibliothèques natives, ressources privées
d’authentification et données de protocole ne sont pas modifiées.

Vérification : ressources françaises extraites de l’APK final, 7 428 identifiants
de ressource stables, 95 cas de formatage exécutés sur la JVM, cinq scénarios de
migration de langue exécutés avec des doublures de l’API Android, vérification
de signature et alignement APK. Les doubles ne constituent pas un test Android
13 réel. Tous les assets et bibliothèques natives, et 19 des 24 DEX, sont identiques
octet par octet à 1.2.2. Les autres changements sont documentés dans le dossier
de validation du paquet de livraison.

La commande CI prescrite par AGENTS.md a été exécutée, mais le téléchargement
de Gradle 9.5.0 a échoué avec `java.net.SocketException: Network is unreachable`.
Les tests complets du projet et le test dans le véhicule restent à effectuer.

Les interfaces projetées depuis le téléphone suivent ses propres réglages de
langue. Les journaux et identifiants techniques conservent leur format d’origine
pour le diagnostic. Les licences et attributions sont conservées ; les sources
publiques ne contiennent aucune clé de signature ou d’authentification.
