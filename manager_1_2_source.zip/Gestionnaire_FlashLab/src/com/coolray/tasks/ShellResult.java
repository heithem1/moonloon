package com.coolray.tasks;

/** A nonzero or absent exit marker is never treated as success. */
public final class ShellResult {
    static final String MARKER = "__FLASHLAB_EXIT_93__:";
    public final String output;
    public final int exit;
    public ShellResult(String output,int exit) { this.output=output;this.exit=exit; }
    public static String wrap(String command) { return command + "; __flashlab_code=$?; printf '\\n" + MARKER + "%s\\n' \"$__flashlab_code\""; }
    public static ShellResult parse(String text) {
        int at=text.lastIndexOf("\n"+MARKER);
        if(at<0)return new ShellResult(text,-1);
        String tail=text.substring(at+MARKER.length()+1).trim();
        if(!tail.matches("[0-9]{1,3}"))return new ShellResult(text,-1);
        return new ShellResult(text.substring(0,at),Integer.parseInt(tail));
    }
    public boolean privilegedIdentity() {
        return exit==0 && java.util.regex.Pattern.compile("(?:^|\\s)uid=(?:0|2000)\\b").matcher(output).find();
    }
}
