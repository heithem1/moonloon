package com.coolray.tasks;

/** Independent stop semantics; no successful cleanup request is reported as a verified force-stop. */
public final class StopController {
    private StopController() {}
    public static final class State {
        public final boolean protectedApp,stopped,background;
        public State(boolean protectedApp,boolean stopped){this(protectedApp,stopped,true);}
        public State(boolean protectedApp,boolean stopped,boolean background){this.protectedApp=protectedApp;this.stopped=stopped;this.background=background;}
    }
    public interface Environment {
        State inspect(String pkg)throws Exception;
        boolean forceAvailable();
        void force(String pkg)throws Exception;
        boolean stopped(String pkg)throws Exception;
        void pause()throws Exception;
        boolean cleanupSupported();
        void cleanup(String pkg)throws Exception;
    }
    public static String run(String pkg,Environment env)throws Exception {
        if(!StopPolicy.validPackage(pkg))throw new SecurityException("Invalid target");
        State state=env.inspect(pkg);
        if(state==null)return "ABSENT";
        if(state.protectedApp)return "PROTECTED";
        if(state.stopped)return "ALREADY";
        if(!state.background)return "NOT_BACKGROUND";
        if(env.forceAvailable()){
            env.force(pkg);
            for(int i=0;i<3;i++){if(env.stopped(pkg))return "CONFIRMED";if(i<2)env.pause();}
            return "UNVERIFIED";
        }
        if(!env.cleanupSupported())return "LIMITED";
        env.cleanup(pkg);return "REQUESTED";
    }
}
