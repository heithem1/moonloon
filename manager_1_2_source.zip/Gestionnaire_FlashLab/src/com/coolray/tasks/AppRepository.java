package com.coolray.tasks;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import java.text.Collator;
import java.util.*;

public final class AppRepository {
    public static final class App {
        public String name,pkg,hardReason;
        public int uid;
        public boolean system,persistent,protectedByUser,detected,stopped;
        public boolean protectedApp(){return hardReason!=null||protectedByUser;}
    }
    public static final class Snapshot {
        public final List<App> apps;
        public final long available,total;
        public final boolean detectionComplete;
        public final String detectionNote;
        Snapshot(List<App> apps,long available,long total,BackgroundProcesses processes){this.apps=apps;this.available=available;this.total=total;this.detectionComplete=processes.complete;this.detectionNote=processes.note;}
    }
    private final Context context;
    private final PackageManager pm;
    private final SharedPreferences prefs;
    public AppRepository(Context c){context=c.getApplicationContext();pm=c.getPackageManager();prefs=c.getSharedPreferences("flash_manager_protection",0);}
    private Set<String> userProtected(){
        return new HashSet<>(prefs.getStringSet("protected",new HashSet<>(Arrays.asList("com.flashlab.connect","com.flashlab.gear","com.flashlab.store","com.flashlab.booster","com.google.android.apps.maps","com.waze"))));
    }
    public void protect(String pkg,boolean value){Set<String> set=userProtected();if(value)set.add(pkg);else set.remove(pkg);prefs.edit().putStringSet("protected",set).apply();}
    public Snapshot load(BackgroundProcesses detected) {
        Set<String> homes=new HashSet<>(),keyboards=new HashSet<>();
        Intent home=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        for(ResolveInfo info:pm.queryIntentActivities(home,PackageManager.MATCH_DEFAULT_ONLY))homes.add(info.activityInfo.packageName);
        ResolveInfo defaultHome=pm.resolveActivity(home,PackageManager.MATCH_DEFAULT_ONLY);if(defaultHome!=null&&defaultHome.activityInfo!=null)homes.add(defaultHome.activityInfo.packageName);
        try{InputMethodManager inputs=(InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
            for(InputMethodInfo keyboard:inputs.getInputMethodList())keyboards.add(keyboard.getPackageName());
        }catch(RuntimeException ignored){}
        List<ApplicationInfo> installed=pm.getInstalledApplications(0);
        Set<Integer> essential=new HashSet<>();
        for(ApplicationInfo a:installed)if(isSystem(a)||a.uid==android.os.Process.myUid()||homes.contains(a.packageName)||keyboards.contains(a.packageName))essential.add(a.uid);
        Set<String> protectedPackages=userProtected();List<App> apps=new ArrayList<>();
        for(ApplicationInfo a:installed){
            if(!a.enabled||a.packageName.equals(context.getPackageName())||!detected.contains(a.packageName)||(a.flags&ApplicationInfo.FLAG_STOPPED)!=0)continue;
            if(isSystem(a)&&pm.getLaunchIntentForPackage(a.packageName)==null)continue;
            App row=new App();row.pkg=a.packageName;row.uid=a.uid;row.name=String.valueOf(pm.getApplicationLabel(a));
            row.system=isSystem(a);row.persistent=(a.flags&ApplicationInfo.FLAG_PERSISTENT)!=0;
            row.hardReason=StopPolicy.hardProtection(row.pkg,row.uid,row.system,row.persistent,context.getPackageName(),essential,homes,keyboards);
            row.protectedByUser=protectedPackages.contains(row.pkg);row.detected=detected.contains(row.pkg);
            row.stopped=(a.flags&ApplicationInfo.FLAG_STOPPED)!=0;apps.add(row);
        }
        Collator french=Collator.getInstance(Locale.FRENCH);apps.sort((a,b)->french.compare(a.name,b.name));
        ActivityManager.MemoryInfo memory=new ActivityManager.MemoryInfo();((ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(memory);
        return new Snapshot(apps,memory.availMem,memory.totalMem,detected);
    }
    private static boolean isSystem(ApplicationInfo a){return (a.flags&(ApplicationInfo.FLAG_SYSTEM|ApplicationInfo.FLAG_UPDATED_SYSTEM_APP))!=0;}
    /** Resolve policy again just before each stop; do not trust a stale UI row. */
    public App current(String pkg){
        try{
            ApplicationInfo a=pm.getApplicationInfo(pkg,0);App row=new App();row.pkg=pkg;row.uid=a.uid;row.system=isSystem(a);row.persistent=(a.flags&ApplicationInfo.FLAG_PERSISTENT)!=0;
            Set<Integer> essential=new HashSet<>();essential.add(android.os.Process.myUid());
            String[] sameUid=pm.getPackagesForUid(a.uid);
            if(sameUid!=null)for(String other:sameUid)if(isSystem(pm.getApplicationInfo(other,0)))essential.add(a.uid);
            Set<String> homes=new HashSet<>(),keyboards=new HashSet<>();Intent home=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            for(ResolveInfo info:pm.queryIntentActivities(home,PackageManager.MATCH_DEFAULT_ONLY))homes.add(info.activityInfo.packageName);
            InputMethodManager inputs=(InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
            for(InputMethodInfo keyboard:inputs.getInputMethodList())keyboards.add(keyboard.getPackageName());
            row.hardReason=StopPolicy.hardProtection(pkg,row.uid,row.system,row.persistent,context.getPackageName(),essential,homes,keyboards);
            row.protectedByUser=userProtected().contains(pkg);row.stopped=(a.flags&ApplicationInfo.FLAG_STOPPED)!=0;return row;
        }catch(PackageManager.NameNotFoundException absent){return null;}
    }
    public boolean stopped(String pkg){try{return (pm.getApplicationInfo(pkg,0).flags&ApplicationInfo.FLAG_STOPPED)!=0;}catch(PackageManager.NameNotFoundException absent){return true;}}
    public String stop(App app,AccessEngine engine)throws Exception {
        return StopController.run(app.pkg,new StopController.Environment(){
            public StopController.State inspect(String pkg){App fresh=current(pkg);return fresh==null?null:new StopController.State(fresh.protectedApp(),fresh.stopped,engine.backgroundProcesses().contains(pkg));}
            public boolean forceAvailable(){return engine.forceAvailable();}
            public void force(String pkg)throws Exception{engine.force(pkg);}
            public boolean stopped(String pkg){return AppRepository.this.stopped(pkg);}
            public void pause()throws InterruptedException{Thread.sleep(100);}
            public boolean cleanupSupported(){return android.os.Build.VERSION.SDK_INT<34;}
            public void cleanup(String pkg){((ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE)).killBackgroundProcesses(pkg);}
        });
    }
}
