package com.coolray.tasks;

import java.util.*;
import java.util.regex.*;

/** A package enters this list only with positive background-state evidence.
 * Installed-app lists, recents, and plain ps output are not background evidence.
 */
public final class BackgroundProcesses {
    public static final int UNKNOWN=0, BACKGROUND=1, FOREGROUND=2, INACTIVE=3;
    public final Set<String> background=new HashSet<>(),foreground=new HashSet<>();
    public boolean complete;
    public String source="Android",note="Détection limitée par Android";
    public int classified;
    public void add(String pkg,int state) {
        if(!StopPolicy.validPackage(pkg))return;
        if(state==FOREGROUND){foreground.add(pkg);background.remove(pkg);}
        else if(state==BACKGROUND&&!foreground.contains(pkg))background.add(pkg);
    }
    public void merge(BackgroundProcesses other){
        for(String p:other.background)add(p,BACKGROUND);
        for(String p:other.foreground)add(p,FOREGROUND);
        classified+=other.classified;
    }
    public boolean contains(String pkg){return background.contains(pkg)&&!foreground.contains(pkg);}
    public static int importance(int value){
        if(value==100||value==200)return FOREGROUND;
        if(value==125||value==130||(value>200&&value<325))return BACKGROUND;
        if(value>=325)return INACTIVE;
        return UNKNOWN;
    }
    static int procState(String text,int sdk){
        if(text==null)return UNKNOWN;
        if(text.matches("[0-9]+")){
            int n;try{n=Integer.parseInt(text);}catch(NumberFormatException malformed){return UNKNOWN;}
            // The vehicle uses Android 9. Do not guess numeric layouts on other releases.
            if(sdk!=28)return UNKNOWN;
            if(n==2)return FOREGROUND;
            if(n>=3&&n<=10)return BACKGROUND;
            return INACTIVE;
        }
        String n=text.toUpperCase(Locale.US).replace("PROCESS_STATE_","");
        if(Arrays.asList("TOP","BTOP","BOUND_TOP","TOP_SLEEPING").contains(n))return FOREGROUND;
        if(Arrays.asList("FOREGROUND_SERVICE","BOUND_FOREGROUND_SERVICE","IMPORTANT_FOREGROUND","IMPORTANT_BACKGROUND","TRANSIENT_BACKGROUND","BACKUP","SERVICE","RECEIVER","FGS","BFGS","IMPF","IMPB","TRNB","BKUP","SVC","RCVR").contains(n))return BACKGROUND;
        if(n.startsWith("CACHED")||Arrays.asList("CEM","CAC","CACC","CRE","HOME","LAST_ACTIVITY","PERSISTENT","PERSISTENT_UI").contains(n))return INACTIVE;
        return UNKNOWN;
    }
    private static final Pattern HEADER=Pattern.compile("(?m)^\\s*\\*APP\\*[^\\r\\n]*?ProcessRecord\\{[^\\r\\n]*?\\s([0-9]+):([^/\\s]+)/[^}\\s]+\\}");
    private static final Pattern STATE=Pattern.compile("\\bcurProcState\\s*=\\s*([A-Za-z0-9_\\-]+)");
    private static final Pattern PACKAGES=Pattern.compile("\\bpackageList\\s*=\\s*\\{([^}]*)\\}");
    public static BackgroundProcesses parse(String dump,int sdk){
        BackgroundProcesses result=new BackgroundProcesses();result.source="Accès avancé";
        if(dump==null||dump.contains("Permission Denial")||dump.contains("Permission denied"))return result;
        Matcher headers=HEADER.matcher(dump);List<Integer> starts=new ArrayList<>(),ends=new ArrayList<>();List<String> names=new ArrayList<>();
        while(headers.find()){starts.add(headers.start());ends.add(headers.end());names.add(headers.group(2));}
        for(int i=0;i<starts.size();i++){
            String block=dump.substring(ends.get(i),i+1<starts.size()?starts.get(i+1):dump.length());
            Matcher state=STATE.matcher(block);if(!state.find())continue;
            int kind=procState(state.group(1),sdk);if(kind==UNKNOWN)continue;
            result.classified++;
            String name=names.get(i);int colon=name.indexOf(':');if(colon>=0)name=name.substring(0,colon);result.add(name,kind);
            Matcher packages=PACKAGES.matcher(block);if(packages.find())for(String pkg:packages.group(1).split(","))result.add(pkg.trim(),kind);
        }
        result.complete=!starts.isEmpty()&&result.classified==starts.size();
        result.note=result.complete?"États des processus vérifiés":"Détection partielle · certaines applications peuvent être masquées";
        return result;
    }
}
