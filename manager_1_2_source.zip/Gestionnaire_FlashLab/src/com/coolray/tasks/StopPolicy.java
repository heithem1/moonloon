package com.coolray.tasks;

import java.util.Set;
import java.util.regex.Pattern;

/** Pure policy shared by single and batch stopping. No shell input comes from app labels. */
public final class StopPolicy {
    private static final Pattern PACKAGE = Pattern.compile("[A-Za-z_][A-Za-z0-9_]*(?:\\.[A-Za-z_][A-Za-z0-9_]*)+");
    private StopPolicy() {}
    public static boolean validPackage(String name) { return name != null && PACKAGE.matcher(name).matches(); }
    public static String hardProtection(String name,int uid,boolean system,boolean persistent,
                                        String self,Set<Integer> essentialUids,Set<String> homes,Set<String> keyboards) {
        if (!validPackage(name)) return "Identifiant non valide";
        if (name.equals(self)) return "Ce gestionnaire";
        if (uid < 0 || uid % 100000 < 10000) return "Service Android";
        if (system || persistent) return "Application système";
        if (essentialUids.contains(uid)) return "Service essentiel partagé";
        if (homes.contains(name)) return "Écran d’accueil";
        if (keyboards.contains(name)) return "Clavier";
        if (name.startsWith("com.android.") || name.startsWith("com.flyme.") ||
            name.startsWith("com.ecarx.") || name.startsWith("ecarx.") ||
            name.startsWith("com.geely.") || name.startsWith("com.coolray.") ||
            name.equals("com.google.android.gms") || name.equals("com.google.android.gsf")) return "Service du véhicule ou d’Android";
        return null;
    }
    public static String forceCommand(String name,int user) {
        if (!validPackage(name) || user < 0) throw new IllegalArgumentException("Invalid target");
        return "am force-stop --user " + user + " " + name;
    }
}
