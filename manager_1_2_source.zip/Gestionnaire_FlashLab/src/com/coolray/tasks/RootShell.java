package com.coolray.tasks;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

public final class RootShell {
    private final String executable;
    public RootShell() { this("su"); }
    RootShell(String executable) { this.executable=executable; }
    public ShellResult run(String command,int timeout) throws Exception {
        final Process process=new ProcessBuilder(executable,"-c",command).redirectErrorStream(true).start();
        final ByteArrayOutputStream out=new ByteArrayOutputStream();
        final IOException[] failure=new IOException[1];
        Thread reader=new Thread(() -> {
            try(InputStream input=process.getInputStream()) {
                byte[] b=new byte[4096];int n;
                while((n=input.read(b))!=-1) {
                    if(out.size()+n>262144)throw new IOException("Output limit");
                    out.write(b,0,n);
                }
            }catch(IOException e){failure[0]=e;process.destroy();}
        },"FlashLab-root-output");
        reader.setDaemon(true);reader.start();
        try {
            if(!process.waitFor(timeout,TimeUnit.MILLISECONDS))throw new IOException("Root timeout");
            reader.join(1000);
            if(reader.isAlive())throw new IOException("Root stream not closed");
            if(failure[0]!=null)throw failure[0];
            return new ShellResult(out.toString("UTF-8"),process.exitValue());
        }finally{process.destroy();try{process.getInputStream().close();}catch(IOException ignored){}}
    }
}
