package com.shilapi.xcertplay

import android.content.Context
import android.content.Intent
import com.shilapi.xcertplay.orchestration.WirelessHotspotMode

/** In-process adapter. It never starts or controls the separately installed DiPlay package. */
object FlashCarPlayBridge {
    fun initialize(context: Context) {
        val migration = context.getSharedPreferences("flash_carplay_defaults", 0)
        if (migration.getBoolean("v1", false)) return
        AirPlayPersistence.saveMediaBufferMillis(context, 1000)
        AirPlayPersistence.saveAudioFocusEnabled(context, false)
        AirPlayPersistence.saveMediaAudioChannel(context, 0)
        AirPlayPersistence.saveNavigationAudioChannel(context, 0)
        AirPlayPersistence.saveFps(context, 30)
        AirPlayPersistence.saveHevcEnabled(context, false)
        AirPlayPersistence.saveWirelessEnabled(context, true)
        AirPlayPersistence.saveWirelessHotspotMode(context, WirelessHotspotMode.MANUAL)
        AirPlayPersistence.saveAutoStartOnBoot(context, false)
        DiPlayPreferences.saveAutoConnect(context, true)
        DiPlayPreferences.saveConnectOnPhoneBluetooth(context, true)
        DiPlayPreferences.saveDefaultConnectionMode(context, DefaultConnectionMode.WIRELESS)
        migration.edit().putBoolean("v1", true).apply()
    }

    fun hasSession(): Boolean = CarPlayBackgroundSession.hasSession()
    fun stop(completion: () -> Unit) = CarPlayBackgroundSession.stop(completion)
    fun selectedPhone(context: Context): String? = DiPlayPreferences.phoneAddress(context)
    fun openIntent(context: Context, settings: Boolean): Intent =
        Intent(context, DiPlayActivity::class.java).apply {
            if (settings) putExtra("page", "settings")
            else putExtra(PhoneBluetoothReceiver.EXTRA_AUTO_CONNECT, true)
        }
}
