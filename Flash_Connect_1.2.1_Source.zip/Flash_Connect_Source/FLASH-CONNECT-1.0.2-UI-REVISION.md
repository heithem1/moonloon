# Flash Connect — UI source revision

- Visible notification, widget and connection labels rebranded.
- Android Auto settings dark/navy/gold palette aligned with CarPlay dark design.
- Harmonized card rounding, spacing and header typography.
- Different functional settings and the two connection engines are preserved.
- Internal code identifiers and open-source notices remain intact.

**Status:** Source patch only. APK build and in-car tests are not yet completed. Gradle 9.5 distribution unavailable in this environment.
