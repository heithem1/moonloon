package com.flashlab.connect

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.andrerinas.headunitrevived.main.SettingsActivity
import com.andrerinas.headunitrevived.utils.Settings
import com.flashlab.connect.brand.FlashBrand
import com.shilapi.xcertplay.AirPlayPersistence
import com.shilapi.xcertplay.AppAppearance
import com.shilapi.xcertplay.DiPlayActivity
import java.io.File
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowAlertDialog

/** Render actual settings at large text sizes; verify presentation cannot rewrite audio defaults. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = TestApplication::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class FlashBrandSettingsUiTest {
    private fun texts(v: View): List<String> = when (v) {
        is TextView -> listOf(v.text.toString())
        is ViewGroup -> (0 until v.childCount).flatMap { texts(v.getChildAt(it)) }
        else -> emptyList()
    }

    private fun categoryKeys(v: View): List<String> {
        val here = (v.tag as? String)?.takeIf { it.startsWith("flash-category:") }?.substringAfter(":")
        return if (here != null) listOf(here)
        else if (v is ViewGroup) (0 until v.childCount).flatMap { categoryKeys(v.getChildAt(it)) }
        else emptyList()
    }

    private fun render(carplay: Boolean, locale: String, width: Int, height: Int) {
        RuntimeEnvironment.setQualifiers("$locale-w${width}dp-h${height}dp-night-mdpi")
        val app = RuntimeEnvironment.getApplication()
        val config = android.content.res.Configuration(app.resources.configuration).apply { fontScale = 1.5f }
        @Suppress("DEPRECATION")
        app.resources.updateConfiguration(config, app.resources.displayMetrics)
        AirPlayPersistence.saveAppAppearance(app, AppAppearance.DARK)
        AirPlayPersistence.saveMediaBufferMillis(app, 1000)
        Settings(app).apply { audioLatencyMultiplier = 1; appLanguage = locale }
        val controller: org.robolectric.android.controller.ActivityController<out Activity> = if (carplay)
            Robolectric.buildActivity(DiPlayActivity::class.java, Intent(app, DiPlayActivity::class.java).putExtra("page", "settings"))
        else Robolectric.buildActivity(SettingsActivity::class.java)
        try {
            val activity = controller.setup().get()
            val view = activity.window.decorView
            view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
            view.layout(0, 0, width, height)
            assertTrue("Flash Connect header must be visible", texts(view).any { it.contains("FLASH CONNECT") })
            assertEquals("Both engines must use the same settings navigation and order",
                com.flashlab.connect.brand.FlashSettingsUi.KEYS.toList(), categoryKeys(view))
            assertEquals(1, Settings(activity).audioLatencyMultiplier)
            assertEquals(1000, AirPlayPersistence.loadMediaBufferMillis(activity))
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            view.draw(Canvas(bitmap))
            val path = File("build/reports/flash-brand/${if (carplay) "carplay" else "android-auto"}-$locale-$width.png")
            path.parentFile.mkdirs()
            path.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
        } finally { controller.pause().stop().destroy() }
    }
    @Test fun carplayCompactFrench() = render(true, "fr", 360, 700)
    @Test fun carplayFullFrench() = render(true, "fr", 1280, 720)
    @Test fun carplayCompactArabic() = render(true, "ar", 360, 700)
    @Test fun androidAutoCompactFrench() = render(false, "fr", 360, 700)
    @Test fun androidAutoFullFrench() = render(false, "fr", 1280, 720)
    @Test fun androidAutoCompactArabic() = render(false, "ar", 360, 700)
    @Test fun aboutShowsOwnerAndLicencesRemainSeparatelyAccessible() {
        val controller = Robolectric.buildActivity(ConnectActivity::class.java).setup()
        try {
            val activity = controller.get()
            FlashBrand.about(activity)
            val about = ShadowAlertDialog.getLatestAlertDialog()
            val copy = texts(about.window!!.decorView).joinToString("\n")
            assertTrue(copy.contains(FlashBrand.OWNER)); assertTrue(copy.contains(FlashBrand.PHONE))
            assertFalse(copy.contains("Headunit Revived"))
            about.dismiss()
            FlashBrand.licences(activity)
            val licences = ShadowAlertDialog.getLatestAlertDialog()
            val legal = texts(licences.window!!.decorView).joinToString("\n")
            assertTrue(legal.contains("Headunit Revived")); assertTrue(legal.contains("DiPlay")); assertTrue(legal.contains("GNU"))
            licences.dismiss()
        } finally { controller.pause().stop().destroy() }
    }
}
