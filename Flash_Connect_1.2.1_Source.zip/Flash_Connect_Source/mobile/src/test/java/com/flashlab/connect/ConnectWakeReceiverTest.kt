package com.flashlab.connect

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = TestApplication::class)
class ConnectWakeReceiverTest {
    private val app get() = RuntimeEnvironment.getApplication()
    private val prefs get() = app.getSharedPreferences(ConnectActivity.PREFS, 0)

    @Before fun reset() {
        prefs.edit().clear().commit()
        app.getSharedPreferences("diplay", 0).edit().clear().commit()
    }

    @Test fun bootResumesOnlyTheSavedModeAndDebouncesRepeatedEvents() {
        prefs.edit().putString(ConnectActivity.LAST, ConnectActivity.CARPLAY).commit()
        val receiver = ConnectWakeReceiver()
        receiver.onReceive(app, Intent(Intent.ACTION_BOOT_COMPLETED))
        val intent = shadowOf(app).nextStartedActivity
        assertEquals(ConnectActivity::class.java.name, intent.component?.className)
        assertTrue(intent.getBooleanExtra(ConnectActivity.EXTRA_RECONNECT, false))
        receiver.onReceive(app, Intent(Intent.ACTION_BOOT_COMPLETED))
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun disablingAutoReconnectPreventsBootLaunch() {
        prefs.edit().putString(ConnectActivity.LAST, ConnectActivity.ANDROID_AUTO)
            .putBoolean(ConnectActivity.AUTO, false).commit()
        ConnectWakeReceiver().onReceive(app, Intent(Intent.ACTION_BOOT_COMPLETED))
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun firstInstallDoesNotGuessAConnectionMode() {
        ConnectWakeReceiver().onReceive(app, Intent(Intent.ACTION_BOOT_COMPLETED))
        assertNull(shadowOf(app).nextStartedActivity)
    }

    @Test fun unrelatedBluetoothDevicesCannotLaunchCarplay() {
        prefs.edit().putString(ConnectActivity.LAST, ConnectActivity.CARPLAY).commit()
        app.getSharedPreferences("diplay", 0).edit().putString("phone_address", "00:11:22:33:44:55").commit()
        val receiver = ConnectWakeReceiver()
        val other = BluetoothAdapter.getDefaultAdapter().getRemoteDevice("00:11:22:33:44:66")
        receiver.onReceive(app, Intent(BluetoothDevice.ACTION_ACL_CONNECTED).putExtra(BluetoothDevice.EXTRA_DEVICE, other))
        assertNull(shadowOf(app).nextStartedActivity)
        val selected = BluetoothAdapter.getDefaultAdapter().getRemoteDevice("00:11:22:33:44:55")
        receiver.onReceive(app, Intent(BluetoothDevice.ACTION_ACL_CONNECTED).putExtra(BluetoothDevice.EXTRA_DEVICE, selected))
        assertNotNull(shadowOf(app).nextStartedActivity)
    }
}
