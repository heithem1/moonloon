package com.flashlab.connect

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.andrerinas.headunitrevived.FlashAutoBridge
import com.andrerinas.headunitrevived.utils.Settings
import com.shilapi.xcertplay.AirPlayPersistence
import com.shilapi.xcertplay.FlashCarPlayBridge
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

/** Avoid hardware initialization; use the real activity, preferences, and mode adapters. */
class TestApplication : ConnectApplication() { override fun onCreate() {} }

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = TestApplication::class, qualifiers = "fr-w1280dp-h720dp-mdpi")
class ConnectActivityTest {
    @Before fun reset() {
        val app = RuntimeEnvironment.getApplication()
        for (name in listOf("flash_connect", "flash_auto_defaults", "flash_carplay_defaults", "xcertplay_airplay", "diplay"))
            app.getSharedPreferences(name, 0).edit().clear().commit()
        FlashAutoBridge.running = false
        FlashAutoBridge.radioReleased = true
        FlashAutoBridge.retryRadioRelease = null
    }

    private fun activity(): ConnectActivity = Robolectric.buildActivity(ConnectActivity::class.java).setup().get()
    private fun buttons(view: View): List<Button> = when (view) {
        is Button -> listOf(view)
        is ViewGroup -> (0 until view.childCount).flatMap { buttons(view.getChildAt(it)) }
        else -> emptyList()
    }

    @Test fun carplayIsAnInternalActivityNotAnotherInstalledPackage() {
        val a = activity()
        buttons(a.window.decorView).first { it.text.startsWith("CarPlay") }.performClick()
        shadowOf(Looper.getMainLooper()).idle()
        val launched = shadowOf(a).nextStartedActivity
        assertEquals(a.packageName, launched.component?.packageName)
        assertEquals("com.shilapi.xcertplay.DiPlayActivity", launched.component?.className)
        assertEquals(android.content.Intent.ACTION_MAIN, launched.action)
        assertTrue(launched.hasCategory(android.content.Intent.CATEGORY_LAUNCHER))
        assertEquals(ConnectActivity.CARPLAY, a.getSharedPreferences(ConnectActivity.PREFS, 0).getString(ConnectActivity.LAST, null))
    }

    @Test fun androidAutoIsLinkedInThisSameApk() {
        val a = activity()
        buttons(a.window.decorView).first { it.text.startsWith("Android Auto") }.performClick()
        shadowOf(Looper.getMainLooper()).idle()
        val launched = shadowOf(a).nextStartedActivity
        assertEquals(a.packageName, launched.component?.packageName)
        assertEquals("com.andrerinas.headunitrevived.main.MainActivity", launched.component?.className)
        assertEquals(android.content.Intent.ACTION_MAIN, launched.action)
        assertTrue(launched.hasCategory(android.content.Intent.CATEGORY_LAUNCHER))
    }

    @Test fun stableDefaultsDoNotOverwriteLaterUserChoices() {
        val app = RuntimeEnvironment.getApplication()
        FlashAutoBridge.initialize(app); FlashCarPlayBridge.initialize(app)
        assertEquals(1, Settings(app).audioLatencyMultiplier)
        assertEquals(3, Settings(app).wifiConnectionMode)
        assertFalse(AirPlayPersistence.loadAudioFocusEnabled(app))
        Settings(app).audioLatencyMultiplier = 2
        AirPlayPersistence.saveAudioFocusEnabled(app, true)
        FlashAutoBridge.initialize(app); FlashCarPlayBridge.initialize(app)
        assertEquals(2, Settings(app).audioLatencyMultiplier)
        assertTrue(AirPlayPersistence.loadAudioFocusEnabled(app))
    }

    @Test fun noDefaultPhoneDoesNotLaunchAnything() {
        val a = activity()
        buttons(a.window.decorView).first { it.text.startsWith("Reconnecter") }.performClick()
        shadowOf(Looper.getMainLooper()).idle()
        assertNull(shadowOf(a).nextStartedActivity)
    }

    @Test fun waitsForWifiReleaseBeforeStartingCarplay() {
        FlashAutoBridge.radioReleased = false
        val a = activity()
        buttons(a.window.decorView).first { it.text.startsWith("CarPlay") }.performClick()
        shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(500))
        assertNull(shadowOf(a).nextStartedActivity)
        FlashAutoBridge.radioReleased = true
        shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofMillis(200))
        assertEquals("com.shilapi.xcertplay.DiPlayActivity", shadowOf(a).nextStartedActivity.component?.className)
    }

    @Test fun timedOutShutdownDoesNotStartTheOtherEngine() {
        FlashAutoBridge.running = true // simulate a service that has not released its transport
        val a = activity()
        buttons(a.window.decorView).first { it.text.startsWith("CarPlay") }.performClick()
        shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(12))
        assertNull(shadowOf(a).nextStartedActivity)
        assertTrue(buttons(a.window.decorView).all { it.isEnabled })
    }
}
