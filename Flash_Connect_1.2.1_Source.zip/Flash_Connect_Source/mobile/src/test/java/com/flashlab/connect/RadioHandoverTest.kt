package com.flashlab.connect

import android.content.Context
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pGroup
import android.net.wifi.p2p.WifiP2pManager
import android.os.Looper
import com.andrerinas.headunitrevived.connection.WifiDirectManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import org.robolectric.shadows.ShadowWifiP2pManager
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = TestApplication::class, shadows = [RadioHandoverTest.Radio::class])
class RadioHandoverTest {
    private val app get() = RuntimeEnvironment.getApplication()
    private val radio get() = shadowOf(app.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager) as Radio

    @Test fun staleOwnerFlagDoesNotBlockWhenAndroidAlreadyRemovedTheGroup() {
        val manager = WifiDirectManager(app)
        ReflectionHelpers.setField(manager, "isGroupOwner", true)
        radio.group = null
        var released: Boolean? = null
        manager.stop { released = it }
        assertEquals(true, released)
    }

    @Test fun failedRemovalWithAnExistingGroupKeepsTheOtherEngineBlocked() {
        val manager = WifiDirectManager(app)
        radio.group = WifiP2pGroup()
        var released: Boolean? = null
        manager.stop { released = it }
        assertEquals(false, released)
    }

    @Test fun pendingGroupCreationCannotRestartWifiAfterShutdown() {
        val manager = WifiDirectManager(app)
        @Suppress("DEPRECATION")
        (app.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = true
        manager.startNativeAaQuietHost()
        manager.stop {}
        shadowOf(Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(5))
        assertEquals(0, radio.creations)
    }

    @Implements(WifiP2pManager::class)
    class Radio : ShadowWifiP2pManager() {
        var group: WifiP2pGroup? = null
        var creations = 0
        @Implementation override fun removeGroup(channel: WifiP2pManager.Channel, listener: WifiP2pManager.ActionListener) {
            listener.onFailure(WifiP2pManager.ERROR)
        }
        @Implementation override fun requestGroupInfo(channel: WifiP2pManager.Channel, listener: WifiP2pManager.GroupInfoListener) {
            listener.onGroupInfoAvailable(group)
        }
        @Implementation override fun createGroup(channel: WifiP2pManager.Channel, listener: WifiP2pManager.ActionListener) {
            creations++
            listener.onSuccess()
        }
    }
}
