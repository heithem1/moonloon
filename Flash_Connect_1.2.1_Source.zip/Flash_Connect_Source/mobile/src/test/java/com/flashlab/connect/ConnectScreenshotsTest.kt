package com.flashlab.connect

import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.View
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = TestApplication::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ConnectScreenshotsTest {
    private fun screenshot(locale: String, width: Int, height: Int, name: String) {
        RuntimeEnvironment.setQualifiers("$locale-w${width}dp-h${height}dp-mdpi")
        val context = RuntimeEnvironment.getApplication()
        val config = android.content.res.Configuration(context.resources.configuration)
        config.fontScale = 1.5f
        @Suppress("DEPRECATION")
        context.resources.updateConfiguration(config, context.resources.displayMetrics)
        val controller = Robolectric.buildActivity(ConnectActivity::class.java).setup()
        val view = controller.get().window.decorView
        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
        view.layout(0, 0, width, height)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        view.draw(Canvas(bitmap))
        val file = File("build/reports/flash-connect-screenshots/$name.png")
        file.parentFile.mkdirs()
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        controller.pause().stop().destroy()
    }

    @Test fun compactLargeFont() = screenshot("fr", 360, 640, "compact-large-font")
    @Test fun fullLargeFont() = screenshot("fr", 1280, 720, "full-large-font")
    @Test fun arabicLargeFont() = screenshot("ar", 360, 640, "arabic-large-font")
}
