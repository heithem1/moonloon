package com.flashlab.connect

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.andrerinas.headunitrevived.FlashAutoBridge
import com.shilapi.xcertplay.FlashCarPlayBridge
import java.lang.ref.WeakReference

open class ConnectApplication : com.andrerinas.headunitrevived.App() {
    private val activities = mutableListOf<WeakReference<Activity>>()

    override fun onCreate() {
        super.onCreate()
        FlashAutoBridge.initialize(this)
        FlashCarPlayBridge.initialize(this)
        registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(a: Activity, state: Bundle?) { activities.add(WeakReference(a)) }
            override fun onActivityDestroyed(a: Activity) { activities.removeAll { it.get() == null || it.get() === a } }
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, state: Bundle) {}
        })
    }

    fun finishEngineActivities() {
        activities.mapNotNull { it.get() }.toList().forEach {
            if (it.javaClass.name.startsWith("com.andrerinas.headunitrevived.") ||
                it.javaClass.name.startsWith("com.shilapi.xcertplay.")) it.finish()
        }
    }
}
