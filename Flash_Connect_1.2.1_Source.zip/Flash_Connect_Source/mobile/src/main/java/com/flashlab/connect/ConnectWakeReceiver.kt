package com.flashlab.connect

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import com.andrerinas.headunitrevived.utils.Settings
import com.shilapi.xcertplay.FlashCarPlayBridge

/** A single wake owner prevents the two engines racing on boot / Bluetooth. */
class ConnectWakeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences(ConnectActivity.PREFS, 0)
        if (!prefs.getBoolean(ConnectActivity.AUTO, true)) return
        val mode = prefs.getString(ConnectActivity.LAST, null) ?: return
        if (intent.action == BluetoothDevice.ACTION_ACL_CONNECTED) {
            @Suppress("DEPRECATION")
            val phone = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
            val address = runCatching { phone.address }.getOrNull() ?: return
            val matches = if (mode == ConnectActivity.CARPLAY)
                FlashCarPlayBridge.selectedPhone(context)?.equals(address, true) == true
            else Settings(context).autoStartBluetoothDeviceMacs.any { it.equals(address, true) } ||
                Settings(context).bluetoothAddress.equals(address, true)
            if (!matches) return
        } else if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val now = SystemClock.elapsedRealtime()
        val prior = prefs.getLong("last_wake", -1)
        if (prior >= 0 && now >= prior && now - prior < WAKE_DEBOUNCE) return
        prefs.edit().putLong("last_wake", now).commit()
        val open = Intent(context, ConnectActivity::class.java)
            .putExtra(ConnectActivity.EXTRA_RECONNECT, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        runCatching { context.startActivity(open) }
    }

    companion object { private const val WAKE_DEBOUNCE = 15_000L }
}
