package com.flashlab.connect

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.andrerinas.headunitrevived.App
import com.andrerinas.headunitrevived.FlashAutoBridge
import com.shilapi.xcertplay.FlashCarPlayBridge

/** Both engines are linked into this APK. No package launcher / APK installation wrapper. */
class ConnectActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private val controls = mutableListOf<View>()
    private var generation = 0
    private var switching = false
    private val gold = Color.rgb(242, 192, 91)
    private val muted = Color.rgb(159, 173, 192)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = Color.rgb(8, 12, 19)
        window.navigationBarColor = Color.rgb(8, 12, 19)
        prefs = getSharedPreferences(PREFS, 0)
        render()
        consumeAutoIntent()
    }

    override fun onNewIntent(next: Intent) {
        super.onNewIntent(next)
        setIntent(next)
        consumeAutoIntent()
    }

    private fun consumeAutoIntent() {
        val auto = intent.getBooleanExtra(EXTRA_RECONNECT, false)
        intent.removeExtra(EXTRA_RECONNECT)
        if (auto && prefs.getBoolean(AUTO, true)) {
            prefs.getString(LAST, null)?.let { mode -> handler.post { choose(mode, false) } }
        }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density + .5f).toInt()
    private fun shape(color: Int, border: Int = color) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(CORNER).toFloat(); setStroke(dp(1), border)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(8, 12, 19)); isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(PADDING), dp(PADDING), dp(PADDING), dp(PADDING))
        }
        scroll.addView(content)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(panel, LinearLayout.LayoutParams(
            minOf(resources.displayMetrics.widthPixels - dp(PADDING * 2), dp(MAX_WIDTH)), -2))
        panel.addView(label("FLASH CONNECT", 30f, gold, true))
        panel.addView(label("Votre téléphone. Votre route.", 16f, muted), gapParams())
        panel.addView(label("Heithem FlashLab  ·  0779 29 15 63", 14f, gold), gapParams())
        status = label("Choisissez votre téléphone pour vous connecter.", 15f, Color.WHITE)
        panel.addView(status, gapParams())
        button(panel, "CarPlay  ·  iPhone", true) { choose(CARPLAY, false) }
        button(panel, "Android Auto  ·  Android", true) { choose(ANDROID_AUTO, false) }
        button(panel, "Reconnecter le dernier téléphone", false) {
            val last = prefs.getString(LAST, null)
            if (last == null) status.text = "Choisissez d’abord CarPlay ou Android Auto."
            else choose(last, false)
        }
        val autoSwitch = Switch(this).apply {
            text = "Reconnexion automatique"; textSize = 17f; setTextColor(Color.WHITE)
            minHeight = dp(CONTROL_HEIGHT)
            isChecked = prefs.getBoolean(AUTO, true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(AUTO, checked).apply() }
        }
        panel.addView(autoSwitch, gapParams())
        panel.addView(label("Reprend le dernier mode au démarrage et au retour du téléphone associé.", 14f, muted))
        button(panel, "Réglages CarPlay", false) { choose(CARPLAY, true) }
        button(panel, "Réglages Android Auto", false) { choose(ANDROID_AUTO, true) }
        button(panel, "Déconnecter", false) { stopAll(null) }
        button(panel, "À propos", false) { com.flashlab.connect.brand.FlashBrand.about(this) }
        setContentView(scroll)
    }

    private fun gapParams() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(GAP) }
    private fun button(parent: LinearLayout, title: String, primary: Boolean, action: () -> Unit) {
        val button = Button(this).apply {
            text = title; isAllCaps = false; textSize = 18f; minHeight = dp(CONTROL_HEIGHT)
            gravity = Gravity.CENTER
            setPadding(dp(GAP), dp(GAP), dp(GAP), dp(GAP))
            setTextColor(if (primary) Color.rgb(8, 12, 19) else Color.WHITE)
            background = shape(if (primary) gold else Color.rgb(17, 27, 42), if (primary) gold else Color.rgb(43, 57, 76))
            setOnClickListener { if (!switching) action() }
        }
        parent.addView(button, gapParams()); controls.add(button)
    }

    private fun choose(mode: String, settings: Boolean) {
        if (mode != CARPLAY && mode != ANDROID_AUTO || switching) return
        val current = prefs.getString(LAST, null)
        val sameActive = current == mode && if (mode == CARPLAY)
            FlashCarPlayBridge.hasSession() && !FlashAutoBridge.running
        else FlashAutoBridge.running && !FlashCarPlayBridge.hasSession()
        if (sameActive) open(mode, settings)
        else stopAll { open(mode, settings) }
    }

    private fun stopAll(next: (() -> Unit)?) {
        if (switching) return
        switching = true
        controls.forEach { it.isEnabled = false }
        status.text = "Fermeture de la connexion précédente…"
        val token = ++generation
        (application as ConnectApplication).finishEngineActivities()
        FlashAutoBridge.stop(this)
        val deadline = SystemClock.elapsedRealtime() + STOP_TIMEOUT
        FlashCarPlayBridge.stop {
            handler.post(object : Runnable {
                override fun run() {
                    if (token != generation || isFinishing || isDestroyed) return
                    if (FlashAutoBridge.running || !FlashAutoBridge.radioReleased || FlashCarPlayBridge.hasSession()) {
                        if (SystemClock.elapsedRealtime() < deadline) { handler.postDelayed(this, STOP_POLL); return }
                        generation++
                        finishSwitch("La connexion précédente n’est pas encore fermée. Réessayez.")
                        return
                    }
                    stopService(Intent(this@ConnectActivity, com.shilapi.xcertplay.DiPlaySessionService::class.java))
                    finishSwitch("Déconnecté.")
                    next?.invoke()
                }
            })
        }
        // A stalled CarPlay shutdown must also restore the controls; never start the other engine.
        handler.postDelayed({
            if (token == generation && switching) {
                generation++
                finishSwitch("Fermeture trop longue. Réessayez.")
            }
        }, STOP_TIMEOUT + STOP_POLL)
    }

    private fun finishSwitch(message: String) {
        switching = false
        controls.forEach { it.isEnabled = true }
        status.text = message
    }

    private fun open(mode: String, settings: Boolean) {
        prefs.edit().putString(LAST, mode).apply()
        val next = if (mode == CARPLAY) FlashCarPlayBridge.openIntent(this, settings)
        else Intent(this, if (settings) com.andrerinas.headunitrevived.main.SettingsActivity::class.java
            else com.andrerinas.headunitrevived.main.MainActivity::class.java)
        if (!settings) {
            // Match a launcher tap so an already connected engine restores its projection screen.
            next.action = Intent.ACTION_MAIN
            next.addCategory(Intent.CATEGORY_LAUNCHER)
        }
        next.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            startActivity(next)
            status.text = if (mode == CARPLAY) "CarPlay sélectionné." else "Android Auto sélectionné."
        } catch (error: RuntimeException) {
            status.text = "Impossible d’ouvrir la connexion : ${error.javaClass.simpleName}."
        }
    }

    override fun onDestroy() {
        generation++
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        const val PREFS = "flash_connect"
        const val LAST = "last_mode"
        const val AUTO = "auto_reconnect"
        const val CARPLAY = "carplay"
        const val ANDROID_AUTO = "android_auto"
        const val EXTRA_RECONNECT = "com.flashlab.connect.RECONNECT"
        private const val PADDING = 24
        private const val GAP = 12
        private const val CORNER = 16
        private const val CONTROL_HEIGHT = 56
        private const val MAX_WIDTH = 760
        private const val STOP_TIMEOUT = 10_000L
        private const val STOP_POLL = 100L
    }
}
