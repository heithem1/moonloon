# Flash Connect 1.2.1

Fixed the debug application label override from DiPlay HUD Test to Flash Connect. Version code 4 allows an update over 1.2. No functional settings or connection changes. APK build, packaged label, version and signature verified. Earlier validation limitations remain in VALIDATION-1.2.md.
