# Flash Connect 1.0.1

Interface et personnalisation : **Heithem FlashLab · 0779 29 15 63**. Voir [FLASH-CONNECT-1.0.1.md](FLASH-CONNECT-1.0.1.md) pour les changements et contrôles de cette version. Les réglages CarPlay et Android Auto partagent une identité or et bleu nuit. À propos et Licences sont séparés.

Application Android unique intégrant deux moteurs de projection dans le même APK et le même processus :

- Android Auto : Headunit Revived `v.3.0.0`, commit `87fc4f3ebb3b` (AGPL-3.0).
- CarPlay : DiPlay `v0.2.16`, commit `bac419695ca2` (GPL-3.0).

Identifiant : `com.flashlab.connect`. Android 7.1/API 25 minimum ; cible de test : Coolray Android 9/API 28.

## Utilisation

Installer l’APK Flash Connect. Ouvrir l’application, choisir CarPlay ou Android Auto et effectuer la première association du téléphone. Les applications d’origine peuvent rester installées comme secours ; les fermer pendant le test Flash Connect.

Les associations, autorisations et le nom/mot de passe du point d’accès sont propres à cette nouvelle application. Les données privées des applications d’origine ne sont pas migrées automatiquement.

La reconnexion automatique mémorise le dernier mode. Elle tente de le rouvrir après BOOT_COMPLETED et lors de la connexion Bluetooth du téléphone sélectionné. Le comportement réel au réveil du véhicule dépend du lancement automatique autorisé par Flyme et doit être testé dans la voiture. Un arrêt forcé Android empêche le démarrage automatique jusqu’à la prochaine ouverture manuelle.

## Réglages initiaux

| Moteur | Réglage |
|---|---|
| Android Auto | Mode natif sans fil, multiplicateur audio 1× |
| CarPlay | Point d’accès de la voiture, H.264, 30 ips |
| CarPlay | Tampon musique 1000 ms, audio focus désactivé |
| CarPlay | Routage média/navigation automatique (0) |

Ces valeurs sont appliquées une seule fois ; les choix faits ensuite dans les réglages sont conservés.

## Intégration

`:mobile` est l’application Flash Connect. `:androidauto` et `:contract` contiennent le moteur AA ; `:common` et `:shared` contiennent CarPlay. Les noms de package internes sont conservés pour limiter les modifications des moteurs.

`ConnectActivity` attend la fin de CarPlay et la destruction du service AA avant de lancer l’autre moteur. Un délai dépassé réactive les boutons sans lancer l’autre moteur. Un seul lanceur et un seul récepteur de démarrage appartiennent à Flash Connect. Les récepteurs automatiques des moteurs sont désactivés. Le composant AA est recréé après destruction, car son ancien gestionnaire de connexion ne peut pas être réutilisé.

## Compilation

JDK 25, Gradle 9.5.0, Android SDK 37.0, build-tools 36.0.0, NDK 28.2.13676358. Renseigner `sdk.dir` dans un fichier local.properties personnel ou ANDROID_HOME.

```sh
./gradlew :mobile:assembleDebug
```

Le code source ne contient aucune identité privée d’authentification CarPlay ni clé de signature. La compilation d’un APK CarPlay autonome utilise le mécanisme amont `DIPLAY_AUTH_ASSETS_DIR`, vers un dossier personnel contenant `offline-mfi/identity.pk8` et `offline-mfi/certificate.p7b`. Un build sans ces éléments compile mais ne peut pas authentifier CarPlay en mode local. Les identités de test et les clés privées ne doivent pas être ajoutées au dépôt source.

Pour une version propriétaire signée, utiliser les variables amont ANDROID_KEYSTORE_PATH, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD ; ne pas ajouter les fichiers de signature aux sources.

Les sorties Java inchangées du compilateur Protobuf sont conservées dans `androidauto/protocol-java` et enregistrées comme sources générées pour Gradle/lint.

## Contrôles

Exécuter les contrôles de AGENTS.md ainsi que `:mobile:testDebugUnitTest`. Les tests ajoutés couvrent les activités internes, les réglages initiaux, leur conservation, l’absence de téléphone sélectionné et un arrêt qui expire. Les rendus du nouvel accueil sont produits par Robolectric sur API 28, format compact/complet avec grande police et locale arabe.

L’intégration n’est pas une validation des radios, des appels, de la reprise après coupure de contact ou de la stabilité audio dans une voiture. Ces points doivent être vérifiés sur le Coolray.

## Licences et attribution

Voir LICENSE (GPL-3.0), LICENSE-ANDROID-AUTO (AGPL-3.0), les notices des dépendances et les README amont. La combinaison est distribuée sous les obligations AGPL-3.0 applicables, avec le code source correspondant. Les marques Android Auto et CarPlay appartiennent à leurs propriétaires respectifs.

## Résultats de cette version

2 257 tests automatisés passent, dont 16 tests Flash Connect et 16 tests du moteur Android Auto. Les contrôles de paquet et de signature passent. Les lints de l’application principale, du lanceur exemple et de l’hôte de carte passent.

Limite : le lint de l’application principale a été exécuté en excluant uniquement `:androidauto:lintAnalyzeDebug`, dont l’analyse de dépendance ne terminait pas dans cet environnement malgré plusieurs tentatives. L’analyse statique complète de cette dépendance reste donc à terminer. Aucun diagnostic n’a été masqué pour fabriquer un résultat positif. Les sorties du compilateur Protobuf sont simplement enregistrées comme sources générées.

Version de test : les connexions radio, le son, les appels et la reconnexion après redémarrage doivent encore être validés dans la voiture.
