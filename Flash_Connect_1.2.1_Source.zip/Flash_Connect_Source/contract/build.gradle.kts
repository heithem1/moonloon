plugins { id("com.android.library") }
android {
    namespace = "com.andrerinas.headunitrevived.contract"
    compileSdk = 37
    defaultConfig { minSdk = 25 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
