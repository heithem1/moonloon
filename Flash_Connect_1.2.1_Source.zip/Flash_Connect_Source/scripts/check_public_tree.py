#!/usr/bin/env python3
"""Fail CI if credential containers or private-key blocks enter the source tree."""
from pathlib import Path
import re
import hashlib
import subprocess

root = Path(__file__).resolve().parents[1]
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
blocked_suffixes = {'.pk8', '.p7b', '.pem', '.key', '.p12', '.pfx', '.jks', '.keystore', '.apk', '.aab'}
private_block = re.compile(rb'-----BEGIN (?:[A-Z0-9 ]+ )?PRIVATE KEY-----\s+[A-Za-z0-9+/=\r\n]{40,}')
# This exact TLS fixture is distributed in the upstream Android Auto source.
# It is not the owner's signing key or the separately provisioned accessory identity.
public_tls_fixtures = {
    "androidauto/src/main/res/raw/privkey": "015d172a6e4d5b7f04a5c820a60a41673f99d6e01c2f658e2a0909efbf6d49f7",
}
failures = []
for name in filter(None, names):
    path = root / name
    if not path.is_file():
        continue
    if name in public_tls_fixtures and hashlib.sha256(path.read_bytes()).hexdigest() == public_tls_fixtures[name]:
        continue
    if '.private' in path.relative_to(root).parts or path.suffix.lower() in blocked_suffixes:
        failures.append(name)
    elif private_block.search(path.read_bytes()):
        failures.append(name)
if failures:
    raise SystemExit('Credential or distribution files are forbidden in the public tree:\n' + '\n'.join(failures))
print('Public tree check passed: no owner credentials; pinned upstream TLS fixture allowed.')
