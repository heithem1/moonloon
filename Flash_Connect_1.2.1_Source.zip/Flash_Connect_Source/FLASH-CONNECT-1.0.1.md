# Flash Connect 1.0.1

Design and customization: **Heithem FlashLab**  
Support: **0779 29 15 63**

The Android Auto and CarPlay settings now share a gold and navy identity, coordinated cards and branded headers. All existing settings categories and callbacks are retained. About presents the customization owner; a separate Licences page contains the original upstream notices and complete GPL/AGPL texts.

Package: `com.flashlab.connect`, version name `1.0.1`, version code `2`.

Connection, protocol and native sources are unchanged. The one-time stable defaults remain Android Auto 1× audio latency and CarPlay 1000 ms music buffering. Existing users' choices and pairing data remain in the same package.

## Build

Use JDK 25, Gradle 9.5.0, Android platform 37.0, build tools 36.0.0 and NDK 28.2.13676358. The standard commands in AGENTS.md apply. Run `:mobile:testDebugUnitTest` as well; `FlashBrandSettingsUiTest` produces the large-text French and Arabic screen captures under `mobile/build/reports/flash-brand/`.

Source-only debug builds contain no accessory identity. A standalone car-test build requires the owner's private authentication asset directory via `DIPLAY_AUTH_ASSETS_DIR`, then `:mobile:assembleStandaloneDebug`. Private assets and signing keys are deliberately excluded from this source archive. Sign the final APK using the original owner key to update an existing install.

## Verification status

APK compiled and signed with the original owner certificate. Package/version and authentication assets were verified; original GPL/AGPL asset bytes are unchanged. Connection/native source comparison: 126 files unchanged. XML parsing passed. Regression and rendered-screen checks are in progress at this checkpoint. Earlier test totals in README.md describe the 1.0 baseline only.

The public-tree scan permits the exact pre-existing upstream Android Auto TLS fixture by SHA-256; owner signing keys and accessory identities remain forbidden in source. The local sandbox test runner supplies Mockito's published Java agent because automatic attachment is unavailable here; no tests are disabled by this adjustment.
