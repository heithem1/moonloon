import org.gradle.api.DefaultTask
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.tasks.InputDirectory
import org.gradle.api.tasks.OutputDirectory
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction

plugins {
    id("com.android.library")
}
android {
    namespace = "com.andrerinas.headunitrevived"
    compileSdk = 37
    defaultConfig {
        minSdk = 25
        buildConfigField("String", "VERSION_NAME", "\"3.0.0-flash-connect\"")
        buildConfigField("int", "VERSION_CODE", "76")
        buildConfigField("String", "AVAILABLE_LOCALES", "\"en,fr,ar\"")
    }
    lint { checkGeneratedSources = false }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
dependencies {
    implementation(project(":shared"))
    api(project(":contract"))
    implementation("org.conscrypt:conscrypt-android:2.5.3")
    implementation("com.google.protobuf:protobuf-java:3.25.1")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.fragment:fragment-ktx:1.6.2")
    implementation("androidx.media:media:1.6.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.10.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.startup:startup-runtime:1.1.1")
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("androidx.navigation:navigation-fragment-ktx:2.3.5")
    implementation("androidx.navigation:navigation-ui-ktx:2.3.5")
    implementation("com.linkedin.dexmaker:dexmaker:2.28.3")
    implementation("com.github.bumptech.glide:glide:4.16.0")
    implementation("com.google.zxing:core:3.5.3")
    testImplementation("junit:junit:4.13.2")
}

// These unchanged protobuf compiler outputs are generated code, not handwritten app code.
abstract class StageProtocolSources : DefaultTask() {
    @get:InputDirectory @get:PathSensitive(PathSensitivity.RELATIVE)
    abstract val inputDirectory: DirectoryProperty
    @get:OutputDirectory abstract val outputDirectory: DirectoryProperty
    @TaskAction fun stage() {
        inputDirectory.get().asFile.copyRecursively(outputDirectory.get().asFile, overwrite = true)
    }
}
val stageProtocolSources = tasks.register<StageProtocolSources>("stageProtocolSources") {
    inputDirectory.set(layout.projectDirectory.dir("protocol-java"))
    outputDirectory.set(layout.buildDirectory.dir("generated/source/flashProtocol"))
}
androidComponents.onVariants { variant ->
    variant.sources.java?.addGeneratedSourceDirectory(stageProtocolSources, StageProtocolSources::outputDirectory)
}
