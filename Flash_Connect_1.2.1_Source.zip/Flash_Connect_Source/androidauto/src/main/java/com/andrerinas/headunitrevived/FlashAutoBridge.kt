package com.andrerinas.headunitrevived

import android.content.Context
import android.content.Intent
import com.andrerinas.headunitrevived.aap.AapService
import com.andrerinas.headunitrevived.utils.Settings

/** The service owns Wi-Fi/Bluetooth release; callers must await [running] == false. */
object FlashAutoBridge {
    @Volatile var running = false
    @Volatile var radioReleased = true
    var retryRadioRelease: (() -> Unit)? = null

    fun initialize(context: Context) {
        val migration = context.getSharedPreferences("flash_auto_defaults", 0)
        if (migration.getBoolean("v1", false)) return
        Settings(context).apply {
            headUnitMake = "FlashLab"
            headUnitModel = "Flash Connect"
            wifiConnectionMode = 3
            audioLatencyMultiplier = 1
            autoConnectLastSession = true
            reopenOnReconnection = true
            autoStartOnBoot = false
            autoStartOnScreenOn = false
            autoStartOnWifi = false
            killOnDisconnect = false
        }
        migration.edit().putBoolean("v1", true).apply()
    }

    fun stop(context: Context) {
        AapService.killProcessOnDestroy = false
        context.stopService(Intent(context, AapService::class.java))
        context.stopService(Intent(context, com.andrerinas.headunitrevived.location.GpsLocationService::class.java))
        context.stopService(Intent(context, com.andrerinas.headunitrevived.aap.DummyVpnService::class.java))
        if (!running) retryRadioRelease?.invoke()
    }
}
