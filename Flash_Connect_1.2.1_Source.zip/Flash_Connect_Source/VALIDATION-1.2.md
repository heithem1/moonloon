# Validation — 20 October 2026

- Final clean Android debug APK build: PASS.
- FlashBrandSettingsUiTest: 7 tests, 0 failures. Checks identical nine-category navigation order, owner/contact and retained licence access, unchanged audio preferences, and renders French compact/full and Arabic compact screens at 1.5 font scale on Android 9/API 28. Screenshots visually reviewed.
- Shared module regression suite: 1,211 tests, 0 failures in the broader run.
- Home sample tests: 4 tests, 0 failures in the broader run.
- Broader common module run: 1,010 tests, 262 failures. Failures include Mockito/ByteBuddy self-attachment initialization in this environment and assertions that expect the previous overview/rail/quick-settings structure. These tests have not all been migrated to the new interface.
- Full prescribed CI command was attempted; it did not pass. Its final broad run also exhausted environment memory. The final focused build/UI validation used one worker and a 2 GiB Gradle heap and passed.
- This is a test candidate. No real-device or in-car Android Auto/CarPlay session has been verified here.
- Private accessory assets from the supplied APK are retained in the private APK, and excluded from this source archive.
