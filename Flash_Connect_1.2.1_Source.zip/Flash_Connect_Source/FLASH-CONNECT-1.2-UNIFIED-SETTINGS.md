# Flash Connect 1.2 test — unified settings

The Android Auto and CarPlay settings now share a navigation component, header, category cards, category order and spacing. Android Auto's original SettingItem objects are grouped into Connection, Display, Audio, Navigation, Vehicle, Diagnostics, Advanced, Language and About. Their original actions, pending values and save/reset code are retained. Search and unsaved-change handling remain available. CarPlay keeps its existing control persistence and reconnect handling.

The settings navigation uses FlashSettingsUi from the shared module. About identifies Heithem FlashLab and 0779 29 15 63; third-party notices remain separately accessible.

This source archive does not contain accessory authentication credentials or signing keys. A private test APK may retain the two local accessory assets from the owner's supplied APK through the existing explicit DIPLAY_AUTH_ASSETS_DIR build option.

Validation status is recorded in VALIDATION-1.2.md. This is an in-car test candidate, not a verified production release.
