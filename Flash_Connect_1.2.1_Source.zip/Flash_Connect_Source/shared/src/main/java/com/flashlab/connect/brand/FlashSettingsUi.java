package com.flashlab.connect.brand;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** One settings navigation and card vocabulary, shared by both projection engines. */
public final class FlashSettingsUi {
    public static final int GAP = 16, INSET = 20, CONTROL = 52, CORNER = 16;
    public static final int BACKGROUND = Color.rgb(8, 12, 19);
    public static final int SURFACE = Color.rgb(17, 27, 42);
    public static final int GOLD = Color.rgb(242, 192, 91);
    public static final int MUTED = Color.rgb(159, 173, 192);
    public static final String[] KEYS = {"connection", "display", "audio", "navigation", "vehicle", "diagnostics", "advanced", "language", "about"};
    private FlashSettingsUi() {}
    public static int dp(Context c, int n) { return Math.round(c.getResources().getDisplayMetrics().density * n); }
    public static String localized(Context c, String en, String fr, String ar) {
        String lang = c.getResources().getConfiguration().getLocales().get(0).getLanguage();
        return "ar".equals(lang) ? ar : "fr".equals(lang) ? fr : en;
    }
    public static String title(Context c, String key) {
        switch (key) {
            case "connection": return localized(c,"Connection","Connexion","الاتصال");
            case "display": return localized(c,"Display","Affichage","العرض");
            case "audio": return localized(c,"Audio","Audio","الصوت");
            case "navigation": return localized(c,"Navigation","Navigation","الملاحة");
            case "vehicle": return localized(c,"Vehicle","Véhicule","السيارة");
            case "diagnostics": return localized(c,"Diagnostics","Diagnostic","التشخيص");
            case "advanced": return localized(c,"Advanced","Avancé","متقدم");
            case "language": return localized(c,"Language","Langue","اللغة");
            case "about": return localized(c,"About","À propos","حول التطبيق");
            default: return localized(c,"Settings","Réglages","الإعدادات");
        }
    }
    public static String summary(Context c, String key) {
        switch (key) {
            case "connection": return localized(c,"Phone, wireless and automatic connection","Téléphone, sans-fil et connexion automatique","الهاتف والاتصال اللاسلكي والتلقائي");
            case "display": return localized(c,"Appearance, resolution and screen layout","Apparence, résolution et disposition","المظهر والدقة وتخطيط الشاشة");
            case "audio": return localized(c,"Music, microphone and voice guidance","Musique, microphone et guidage vocal","الموسيقى والميكروفون والتوجيه الصوتي");
            case "navigation": return localized(c,"Location and driving guidance","Localisation et aide à la conduite","الموقع وإرشادات القيادة");
            case "vehicle": return localized(c,"Vehicle profile and steering controls","Profil du véhicule et commandes au volant","ملف السيارة وأزرار المقود");
            case "diagnostics": return localized(c,"Logs and troubleshooting","Journaux et dépannage","السجلات وحل المشكلات");
            case "advanced": return localized(c,"Compatibility and specialist options","Compatibilité et options spécifiques","التوافق والخيارات المتخصصة");
            case "language": return localized(c,"Choose your preferred language","Choisissez votre langue","اختر لغتك المفضلة");
            default: return "Heithem FlashLab · 0779 29 15 63";
        }
    }
    private static String glyph(String key) {
        switch(key) {
            case "connection": return "↔"; case "display": return "▣"; case "audio": return "♫";
            case "navigation": return "➤"; case "vehicle": return "◇"; case "diagnostics": return "≡";
            case "advanced": return "⚙"; case "language": return "文"; default: return "i";
        }
    }
    private static TextView text(Context c, String value, int size, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }
    public static void styleCard(View view) {
        Context c = view.getContext(); GradientDrawable bg = new GradientDrawable();
        bg.setColor(SURFACE); bg.setCornerRadius(dp(c,CORNER)); bg.setStroke(dp(c,1), Color.rgb(87,73,47));
        view.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33F2C05B),bg,null));
        view.setPaddingRelative(dp(c,INSET),dp(c,16),dp(c,INSET),dp(c,16));
        view.setMinimumHeight(dp(c,CONTROL));
    }
    private static TextView action(Context c, String value, String description, Runnable click) {
        TextView v = text(c,value,24,GOLD,true); v.setGravity(Gravity.CENTER);
        v.setTextDirection(View.TEXT_DIRECTION_LTR);
        v.setContentDescription(description); v.setClickable(true); v.setFocusable(true);
        styleCard(v); v.setPadding(0,0,0,0); v.setOnClickListener(w -> click.run()); return v;
    }
    public static LinearLayout header(Context c, String mode, String page, Runnable back, Runnable menu) {
        LinearLayout row = new LinearLayout(c); row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(action(c,c.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL ? "›" : "‹",localized(c,"Back","Retour","رجوع"),back), new LinearLayout.LayoutParams(dp(c,CONTROL),dp(c,CONTROL)));
        LinearLayout words = new LinearLayout(c); words.setOrientation(LinearLayout.VERTICAL);
        words.setPaddingRelative(dp(c,GAP),0,dp(c,GAP),0);
        TextView name = text(c,"FLASH CONNECT",19,GOLD,true); name.setLetterSpacing(.05f); words.addView(name);
        TextView subtitle = text(c,"overview".equals(page) ? mode : mode+" · "+title(c,page),13,MUTED,false);
        subtitle.setSingleLine(true); subtitle.setEllipsize(android.text.TextUtils.TruncateAt.END); words.addView(subtitle);
        row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(action(c,"⋮",localized(c,"Options","Options","خيارات"),menu), new LinearLayout.LayoutParams(dp(c,CONTROL),dp(c,CONTROL)));
        return row;
    }
    public static LinearLayout category(Context c, String key, Runnable click) {
        LinearLayout card = new LinearLayout(c); card.setOrientation(LinearLayout.VERTICAL); styleCard(card);
        LinearLayout row = new LinearLayout(c); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(c,glyph(key),25,GOLD,true); icon.setGravity(Gravity.CENTER); icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        LinearLayout.LayoutParams iconSize = new LinearLayout.LayoutParams(dp(c,32),dp(c,40)); iconSize.setMarginEnd(dp(c,16)); row.addView(icon,iconSize);
        LinearLayout words = new LinearLayout(c); words.setOrientation(LinearLayout.VERTICAL);
        words.addView(text(c,title(c,key),18,Color.WHITE,true));
        TextView summary = text(c,summary(c,key),14,MUTED,false); summary.setPadding(0,dp(c,4),0,0); words.addView(summary);
        row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView chevron = text(c,c.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL ? "‹" : "›",24,GOLD,true); chevron.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        chevron.setTextDirection(View.TEXT_DIRECTION_LTR);
        LinearLayout.LayoutParams arrowSize = new LinearLayout.LayoutParams(dp(c,24),-2);
        arrowSize.setMarginStart(dp(c,GAP)); row.addView(chevron,arrowSize); card.addView(row);
        card.setTag("flash-category:" + key);
        card.setClickable(true); card.setFocusable(true); card.setContentDescription(title(c,key));
        card.setOnClickListener(v -> click.run()); return card;
    }
}
