package com.flashlab.connect.brand;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Shared presentation only. Does not read or write connection preferences. */
public final class FlashBrand {
    public static final String NAME = "Flash Connect";
    public static final String OWNER = "Heithem FlashLab";
    public static final String PHONE = "0779 29 15 63";
    private static final int GOLD = Color.rgb(242, 192, 91);
    private static final int NAVY = Color.rgb(8, 12, 19);
    private static final int SURFACE = Color.rgb(17, 27, 42);
    private static final int INSET = 20;
    private static final int GAP = 12;
    private static final int CORNER = 16;
    private FlashBrand() {}
    private static int dp(Context c, int n) { return Math.round(n * c.getResources().getDisplayMetrics().density); }
    private static String localized(Context c, String en, String fr, String ar) {
        String lang = c.getResources().getConfiguration().getLocales().get(0).getLanguage();
        return "ar".equals(lang) ? ar : "fr".equals(lang) ? fr : en;
    }
    public static String licencesLabel(Context c) { return localized(c, "Licences", "Licences", "التراخيص"); }
    private static TextView text(Context c, String s, int size, int color, boolean medium) {
        TextView v = new TextView(c); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if (medium) v.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return v;
    }
    public static View identity(Context c) {
        LinearLayout body = new LinearLayout(c); body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(c, INSET), dp(c, INSET), dp(c, INSET), dp(c, INSET));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(SURFACE); bg.setCornerRadius(dp(c, CORNER));
        bg.setStroke(dp(c, 1), Color.rgb(102, 83, 50)); body.setBackground(bg);
        TextView name = text(c, "FLASH CONNECT", 22, GOLD, true); name.setLetterSpacing(.08f); body.addView(name);
        TextView owner = text(c, localized(c, "Design & customization by ", "Conçu et personnalisé par ", "تصميم وتخصيص ") + OWNER, 16, Color.WHITE, false);
        LinearLayout.LayoutParams line = new LinearLayout.LayoutParams(-1, -2); line.topMargin = dp(c, GAP); body.addView(owner, line);
        TextView phone = text(c, PHONE, 20, GOLD, true); phone.setTextDirection(View.TEXT_DIRECTION_LTR); phone.setTextIsSelectable(true);
        LinearLayout.LayoutParams phoneLine = new LinearLayout.LayoutParams(-1, -2); phoneLine.topMargin = dp(c, GAP); body.addView(phone, phoneLine);
        return body;
    }
    private static void style(AlertDialog d) {
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(NAVY));
        for (int which : new int[]{AlertDialog.BUTTON_POSITIVE, AlertDialog.BUTTON_NEUTRAL})
            if (d.getButton(which) != null) d.getButton(which).setTextColor(GOLD);
    }
    public static void about(Activity a) {
        AlertDialog d = new AlertDialog.Builder(a).setView(identity(a))
            .setNeutralButton(licencesLabel(a), (dialog, which) -> licences(a))
            .setPositiveButton(localized(a, "Close", "Fermer", "إغلاق"), null).create();
        d.show(); style(d);
    }
    public static void licences(Activity a) {
        StringBuilder content = new StringBuilder();
        for (String asset : new String[]{"FLASH_CONNECT_NOTICES.txt", "LICENSE-ANDROID-AUTO", "LICENSE"}) {
            try (InputStream input = a.getAssets().open(asset)) {
                java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[8192]; int n;
                while ((n = input.read(buffer)) != -1) bytes.write(buffer, 0, n);
                content.append(new String(bytes.toByteArray(), StandardCharsets.UTF_8)).append("\n\n");
            } catch (java.io.IOException error) {
                content.append(asset).append(": ").append(localized(a, "Unavailable", "Indisponible", "غير متاح")).append("\n");
            }
        }
        ScrollView scroll = new ScrollView(a); scroll.setBackgroundColor(NAVY);
        TextView legal = text(a, content.toString(), 14, Color.WHITE, false); legal.setTextIsSelectable(true);
        legal.setPadding(dp(a, INSET), dp(a, INSET), dp(a, INSET), dp(a, INSET)); scroll.addView(legal);
        TextView title = text(a, licencesLabel(a), 22, GOLD, true);
        title.setPadding(dp(a, INSET), dp(a, INSET), dp(a, INSET), dp(a, GAP));
        AlertDialog d = new AlertDialog.Builder(a).setCustomTitle(title).setView(scroll)
            .setPositiveButton(localized(a, "Close", "Fermer", "إغلاق"), null).create();
        d.show(); style(d);
    }
}
