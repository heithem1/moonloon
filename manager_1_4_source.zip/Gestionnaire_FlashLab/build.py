#!/usr/bin/env python3
"""Small reproducible Android 9 build; external tools and signing credentials stay outside sources."""
from pathlib import Path
import argparse,subprocess,zipfile,shutil

p=argparse.ArgumentParser()
p.add_argument('--build-tools',type=Path,required=True)
p.add_argument('--android-jar',type=Path,required=True)
p.add_argument('--ecj',type=Path,required=True)
p.add_argument('--keystore',type=Path,required=True)
p.add_argument('--password-file',type=Path,required=True)
p.add_argument('--alias',default='flashlab')
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
base=Path(__file__).resolve().parent
work=base/'build';work.mkdir(exist_ok=True)
for folder in ['classes','dex','generated']:
    target=work/folder
    if target.exists():shutil.rmtree(target)
    target.mkdir()
def run(args):subprocess.run([str(x) for x in args],check=True)
run([a.build_tools/'aapt2','compile','--dir',base/'res','-o',work/'resources.zip'])
run([a.build_tools/'aapt2','link','-o',work/'resources.apk','--manifest',base/'AndroidManifest.xml','-I',a.android_jar,'--java',work/'generated','-A',base/'assets',work/'resources.zip'])
sources=[x for folder in ['src','vendor'] for x in (base/folder).rglob('*.java')]+list((work/'generated').rglob('*.java'))
boot=str(a.android_jar)+':'+str(a.build_tools/'core-lambda-stubs.jar')
run(['java','-jar',a.ecj,'-source','8','-target','8','-encoding','UTF-8','-bootclasspath',boot,'-d',work/'classes',*sources])
with zipfile.ZipFile(work/'classes.zip','w') as z:
    for f in sorted((work/'classes').rglob('*.class')):z.write(f,f.relative_to(work/'classes'))
run(['java','-cp',a.build_tools/'lib/d8.jar','com.android.tools.r8.D8','--min-api','28','--lib',a.android_jar,'--output',work/'dex',work/'classes.zip'])
with zipfile.ZipFile(work/'resources.apk') as resource,zipfile.ZipFile(work/'unsigned.apk','w') as z:
    for i in resource.infolist():z.writestr(i,resource.read(i.filename))
    z.write(work/'dex/classes.dex','classes.dex')
run([a.build_tools/'zipalign','-f','4',work/'unsigned.apk',work/'aligned.apk'])
a.output.parent.mkdir(exist_ok=True,parents=True)
run(['java','-jar',a.build_tools/'lib/apksigner.jar','sign','--ks',a.keystore,'--ks-key-alias',a.alias,'--ks-pass','file:'+str(a.password_file),'--v1-signing-enabled','true','--v2-signing-enabled','true','--out',a.output,work/'aligned.apk'])
run(['java','-jar',a.build_tools/'lib/apksigner.jar','verify','--verbose',a.output])
run([a.build_tools/'zipalign','-c','4',a.output])
print('Built',a.output)
