package com.coolray.tasks;

/** A short, labelled display-only snapshot. Never used to authorize a stop. */
public final class ScanHistory {
    static final long MAX_AGE_MS=30000;
    private BackgroundProcesses verified;
    private long verifiedAt;
    public void clear(){verified=null;}
    public BackgroundProcesses accept(BackgroundProcesses fresh,long now){
        if(!fresh.interrupted){
            if(fresh.complete){verified=fresh.copy();verifiedAt=now;}
            return fresh;
        }
        if(verified!=null&&now>=verifiedAt&&now-verifiedAt<=MAX_AGE_MS){
            BackgroundProcesses retained=verified.copy();retained.stale=true;retained.interrupted=true;retained.complete=false;
            for(String pkg:fresh.foreground)retained.add(pkg,BackgroundProcesses.FOREGROUND);
            retained.note="Dernière liste vérifiée il y a "+((now-verifiedAt)/1000)+" s · reconnexion en cours · arrêts suspendus";
            return retained;
        }
        return fresh;
    }
}
