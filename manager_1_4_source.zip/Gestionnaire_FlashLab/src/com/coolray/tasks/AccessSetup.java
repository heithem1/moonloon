package com.coolray.tasks;
/** Honest first-install guidance: never equate missing access with an empty process list. */
public final class AccessSetup {
 public enum Issue { NONE,AUTH_REQUIRED,ADB_DISABLED,CONNECTION_FAILED,ROOT_DENIED,SYSTEM_DENIED }
 public static Issue failure(Throwable error){for(int n=0;error!=null&&n<8;n++,error=error.getCause()){if(error instanceof SecurityException)return Issue.AUTH_REQUIRED;if(error instanceof java.net.ConnectException)return Issue.ADB_DISABLED;}return Issue.CONNECTION_FAILED;}
 public static String message(Issue issue){switch(issue){
 case AUTH_REQUIRED:return "Autorisation Android requise pour ce véhicule. Appuyez sur Autoriser cet appareil, puis acceptez la demande si elle apparaît.";
 case ADB_DISABLED:return "Le service ADB local ne répond pas. Le flasheur doit activer l’accès sur cette voiture avant la première utilisation.";
 case ROOT_DENIED:return "Accès root absent ou refusé. Choisissez Automatique ou autorisez le gestionnaire root déjà installé.";
 case SYSTEM_DENIED:return "Le firmware n’accorde pas l’accès système. Choisissez Automatique pour utiliser ADB local autorisé.";
 case CONNECTION_FAILED:return "Connexion aux applications interrompue. Nouvelle tentative automatique ; utilisez Activer l’accès si une autorisation est nécessaire.";
 default:return "Accès aux applications à configurer sur ce véhicule.";
 }}
 private AccessSetup(){}
}
