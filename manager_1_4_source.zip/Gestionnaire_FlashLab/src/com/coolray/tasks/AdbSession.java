package com.coolray.tasks;

import com.cgutman.adblib.AdbCrypto;
import java.io.*;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.TimeUnit;

/** Bounded single-stream ADB client. The Android adapter connects only to 127.0.0.1. */
public final class AdbSession implements Closeable {
    static final int CNXN=0x4e584e43,AUTH=0x48545541,OPEN=0x4e45504f,OKAY=0x59414b4f,WRTE=0x45545257,CLSE=0x45534c43;
    static final int LIMIT=1024*1024,OUTPUT_LIMIT=262144;
    private final Socket socket;
    private final DataInputStream input;
    private final OutputStream output;
    private final AdbCrypto crypto;
    private int localId;
    private volatile boolean ready;
    AdbSession(Socket socket,AdbCrypto crypto)throws IOException {
        this.socket=socket;this.crypto=crypto;
        input=new DataInputStream(socket.getInputStream());output=socket.getOutputStream();socket.setTcpNoDelay(true);
    }
    static final class Packet {
        final int command,a,b;final byte[] data;
        Packet(int command,int a,int b,byte[] data){this.command=command;this.a=a;this.b=b;this.data=data;}
    }
    static byte[] encode(int command,int a,int b,byte[] data) {
        int checksum=0;for(byte value:data)checksum+=value&255;
        ByteBuffer buffer=ByteBuffer.allocate(24+data.length).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(command).putInt(a).putInt(b).putInt(data.length).putInt(checksum).putInt(command^0xffffffff).put(data);
        return buffer.array();
    }
    private void send(int command,int a,int b,byte[] data)throws IOException {output.write(encode(command,a,b,data));output.flush();}
    private Packet receive(long deadline)throws IOException {
        byte[] header=new byte[24];readFully(header,deadline);
        ByteBuffer h=ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);
        int command=h.getInt(),a=h.getInt(),b=h.getInt(),size=h.getInt(),checksum=h.getInt(),magic=h.getInt();
        if(magic!=(command^0xffffffff)||size<0||size>LIMIT)throw new IOException("Invalid ADB packet");
        byte[] data=new byte[size];readFully(data,deadline);int sum=0;for(byte v:data)sum+=v&255;
        if(sum!=checksum)throw new IOException("ADB checksum mismatch");
        return new Packet(command,a,b,data);
    }
    private void readFully(byte[] buffer,long deadline)throws IOException {
        int offset=0;
        while(offset<buffer.length){
        long remaining=deadline-System.nanoTime();
        if(remaining<=0)throw new java.net.SocketTimeoutException("ADB deadline");
        socket.setSoTimeout((int)Math.min(30000,Math.max(1,TimeUnit.NANOSECONDS.toMillis(remaining))));
        int n=input.read(buffer,offset,buffer.length-offset);
        if(n<0)throw new EOFException("ADB closed");offset+=n;
        }
    }
    public synchronized void connect(boolean allowPair,int timeout)throws Exception {
        long deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(timeout);
        send(CNXN,0x01000000,4096,"host::\0".getBytes("UTF-8"));
        boolean signed=false,published=false;
        while(true) {
            Packet p=receive(deadline);
            if(p.command==CNXN){ready=true;return;}
            if(p.command!=AUTH||p.a!=1||p.data.length!=20)throw new IOException("Unexpected ADB authentication");
            if(!signed){send(AUTH,2,0,crypto.signAdbTokenPayload(p.data));signed=true;}
            else if(allowPair&&!published){send(AUTH,3,0,crypto.getAdbPublicKeyPayload());published=true;}
            else throw new SecurityException("ADB authorization required");
        }
    }
    public synchronized ShellResult shell(String command,int timeout)throws Exception {
        if(!ready||socket.isClosed())throw new IOException("ADB disconnected");
        byte[] service=("shell:"+ShellResult.wrap(command)+"\0").getBytes("UTF-8");
        if(service.length>4096)throw new IOException("Command limit");
        int local=++localId,remote=0;
        long deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(timeout);
        send(OPEN,local,0,service);
        ByteArrayOutputStream data=new ByteArrayOutputStream();
        while(true) {
            Packet p=receive(deadline);
            // Late packets for an already closed stream are legal; do not tear down
            // the authenticated transport at the next refresh.
            if(p.b!=local){
                if((p.command==CLSE||p.command==OKAY||p.command==WRTE)&&p.b>0&&p.b<local)continue;
                throw new IOException("ADB stream mismatch");
            }
            if(p.command==OKAY){if(remote!=0&&remote!=p.a)throw new IOException("ADB peer mismatch");remote=p.a;}
            else if(p.command==WRTE){
                if(remote==0||remote!=p.a)throw new IOException("Unexpected ADB payload");
                if(data.size()+p.data.length>OUTPUT_LIMIT)throw new IOException("ADB output limit");
                data.write(p.data);send(OKAY,local,remote,new byte[0]);
            }else if(p.command==CLSE){
                if(remote!=0&&p.a!=0&&remote!=p.a)throw new IOException("ADB close mismatch");
                // The device closed this stream. Protocol CLSE is not acknowledged.
                return ShellResult.parse(data.toString("UTF-8"));
            }else throw new IOException("Unexpected ADB stream packet");
        }
    }
    public boolean isOpen(){return ready&&!socket.isClosed();}
    @Override public void close()throws IOException {ready=false;socket.close();}
}
