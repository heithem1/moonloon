package com.coolray.tasks;

import java.io.IOException;

/** Compact read-only process scan with one authorized transport reconnect. */
public final class ProcessScanner {
    static final String END="__FLASHLAB_DUMP_STATUS_94__:";
    // Filter on the device: a full vehicle dump can exceed the bounded ADB buffer.
    // Preserve a separate dumpsys exit status; grep success alone proves nothing.
    static final String COMMAND="{ dumpsys activity processes; __flashlab_dump_code=$?; printf '\\n"+END+"%s\\n' \"$__flashlab_dump_code\"; } | grep -E '^[[:space:]]*\\*APP\\*|packageList=|curProcState=|foregroundActivities=|Permission|"+END+"'";
    public interface Transport {
        ShellResult run(String command,int timeout)throws Exception;
        boolean reconnect()throws Exception;
    }
    public static BackgroundProcesses parse(ShellResult value,int sdk)throws IOException {
        if(value.exit!=0)throw new IOException("Scan command failed");
        int at=value.output.lastIndexOf("\n"+END);
        if(at<0||!value.output.substring(at+1+END.length()).trim().equals("0"))throw new IOException("Incomplete process dump");
        BackgroundProcesses result=BackgroundProcesses.parse(value.output.substring(0,at),sdk);
        if(result.classified==0)throw new IOException("No process states read");
        return result;
    }
    public static BackgroundProcesses read(Transport transport,int sdk){
        Exception failure=null;
        for(int attempt=0;attempt<2;attempt++){
            try{return parse(transport.run(COMMAND,10000),sdk);}
            catch(Exception error){failure=error;}
            if(Thread.currentThread().isInterrupted())break;
            if(attempt==0)try{if(transport.reconnect())continue;}catch(Exception denied){failure=denied;}
            break;
        }
        BackgroundProcesses result=new BackgroundProcesses();result.interrupted=true;
        result.note="Lecture interrompue · nouvelle tentative automatique";
        if(failure instanceof java.net.SocketTimeoutException)result.note="Lecture trop lente · nouvelle tentative automatique";
        if(failure instanceof SecurityException)result.note="ADB à autoriser · ouvrir Accès avancé";
        return result;
    }
}
