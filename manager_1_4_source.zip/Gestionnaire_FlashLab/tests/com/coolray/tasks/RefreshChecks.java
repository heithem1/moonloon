package com.coolray.tasks;

import com.cgutman.adblib.AdbCrypto;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class RefreshChecks {
    static void repeatedStreams()throws Exception {
        AdbCrypto crypto=AdbCrypto.generateAdbKeyPair(bytes->Base64.getEncoder().encodeToString(bytes));
        ManagerChecks.connection(s->{
            ManagerChecks.read(s.getInputStream());ManagerChecks.send(s,AdbSession.CNXN,0x01000000,4096,new byte[0]);
            int previous=0;
            for(int i=0;i<40;i++){
                ManagerChecks.Packet open=ManagerChecks.read(s.getInputStream());
                ManagerChecks.equal(open.cmd,AdbSession.OPEN,"repeated refresh opens a fresh stream without close echo");
                // Older adbd builds can deliver a delayed duplicate close from a previous stream.
                if(previous!=0)ManagerChecks.send(s,AdbSession.CLSE,70,previous,new byte[0]);
                ManagerChecks.send(s,AdbSession.OKAY,70,open.a,new byte[0]);
                ManagerChecks.send(s,AdbSession.WRTE,70,open.a,("scan "+i+"\n"+ShellResult.MARKER+"0\n").getBytes(StandardCharsets.UTF_8));
                ManagerChecks.equal(ManagerChecks.read(s.getInputStream()).cmd,AdbSession.OKAY,"payload acknowledged");
                ManagerChecks.send(s,AdbSession.CLSE,70,open.a,new byte[0]);previous=open.a;
            }
        },c->{c.connect(false,2500);for(int i=0;i<40;i++){ShellResult value=c.shell("id",2500);ManagerChecks.equal(value.output,"scan "+i,"successive refresh output");ManagerChecks.equal(value.exit,0,"successive refresh exit");}},crypto);
    }
    static ShellResult complete(String dump){return new ShellResult(dump+"\n"+ProcessScanner.END+"0\n",0);}
    static void recovery()throws Exception {
        final String service=ManagerChecks.process("com.google.android.youtube","3","com.google.android.youtube");
        final int[] calls={0},reconnects={0};
        BackgroundProcesses result=ProcessScanner.read(new ProcessScanner.Transport(){
            public ShellResult run(String command,int timeout)throws Exception{
                ManagerChecks.equal(timeout,10000,"bounded scan timeout");
                if(calls[0]++==0)throw new EOFException("ADB closed");return complete(service);
            }
            public boolean reconnect(){reconnects[0]++;return true;}
        },28);
        ManagerChecks.check(result.contains("com.google.android.youtube")&&!result.interrupted,"authorized reconnect restores background music app");
        ManagerChecks.equal(calls[0],2,"read retried once");ManagerChecks.equal(reconnects[0],1,"one reconnect per failed scan");
        calls[0]=0;reconnects[0]=0;
        result=ProcessScanner.read(new ProcessScanner.Transport(){
            public ShellResult run(String command,int timeout)throws Exception{calls[0]++;throw new IOException("ADB closed");}
            public boolean reconnect(){reconnects[0]++;return true;}
        },28);
        ManagerChecks.check(result.interrupted&&!result.complete,"persistent transport failure explicit");ManagerChecks.equal(calls[0],2,"retry bound prevents loop");ManagerChecks.equal(reconnects[0],1,"reconnect bounded");
        result=ProcessScanner.read(new ProcessScanner.Transport(){
            public ShellResult run(String command,int timeout)throws Exception{throw new EOFException();}
            public boolean reconnect(){throw new SecurityException("not authorized");}
        },28);
        ManagerChecks.check(result.interrupted&&result.note.contains("autoriser"),"authorization failure asks for explicit access");
        for(ShellResult invalid:new ShellResult[]{new ShellResult(service,0),new ShellResult(service+"\n"+ProcessScanner.END+"1\n",0),new ShellResult(service+"\n"+ProcessScanner.END+"0\nextra",0),new ShellResult("\n"+ProcessScanner.END+"0\n",0),new ShellResult(service,1)}){
            ManagerChecks.fails(()->ProcessScanner.parse(invalid,28),"incomplete or failed dump rejected");
        }
        ManagerChecks.check(ProcessScanner.parse(complete(service),28).contains("com.google.android.youtube"),"foreground-service media counted as background");
        String widget=ManagerChecks.process("com.media.widget","5","com.media.widget");
        ManagerChecks.check(ProcessScanner.parse(complete(widget),28).contains("com.media.widget"),"perceptible service bound to widget counted");
        String active=ManagerChecks.process("com.media.widget","5","com.media.widget")+"    foregroundActivities=true (rep=true)\n";
        ManagerChecks.check(!ProcessScanner.parse(complete(active),28).contains("com.media.widget"),"actual foreground activity overrides service state");
    }
    static void retention()throws Exception {
        ScanHistory history=new ScanHistory();
        BackgroundProcesses live=BackgroundProcesses.parse(ManagerChecks.process("com.youtube.music","3","com.youtube.music"),28);
        ManagerChecks.check(!history.accept(live,1000).stale,"fresh process result used immediately");
        BackgroundProcesses failed=new BackgroundProcesses();failed.interrupted=true;
        BackgroundProcesses retained=history.accept(failed,6000);
        ManagerChecks.check(retained.contains("com.youtube.music")&&retained.stale&&retained.interrupted&&!retained.complete,"failed read retains labelled last observation");
        ManagerChecks.check(!live.stale&&!live.interrupted,"retention does not mutate authoritative result");
        failed.add("com.youtube.music",BackgroundProcesses.FOREGROUND);
        ManagerChecks.check(!history.accept(failed,10000).contains("com.youtube.music"),"fresh foreground evidence removes stale row");
        ManagerChecks.check(!history.accept(failed,32000).contains("com.youtube.music"),"old observation expires after thirty seconds");
        BackgroundProcesses empty=BackgroundProcesses.parse(ManagerChecks.process("com.cached.only","18","com.cached.only"),28);
        ManagerChecks.check(history.accept(empty,33000).background.isEmpty(),"verified empty result replaces previous music list immediately");
        ManagerChecks.check(history.accept(failed,34000).background.isEmpty(),"empty verified list is retained as empty");
        history.clear();ManagerChecks.check(history.accept(failed,35000).background.isEmpty(),"explicit normal mode clears previous privileged observation");
    }
    static void compactLargeDump()throws Exception {
        Path dir=Files.createTempDirectory("flashlab-scan-test-");Path input=dir.resolve("sample.txt"),script=dir.resolve("dumpsys");
        StringBuilder raw=new StringBuilder();
        for(int i=0;i<250;i++){
            raw.append(ManagerChecks.process("com.media.app"+i,"3","com.media.app"+i));
            for(int j=0;j<40;j++)raw.append("      unnecessary verbose process details: 012345678901234567890123456789012345678901234567890123456789\n");
        }
        Files.write(input,raw.toString().getBytes(StandardCharsets.UTF_8));
        Files.write(script,("#!/bin/sh\ncat \"$FLASHLAB_SCAN_TEST_INPUT\"\nexit 0\n").getBytes(StandardCharsets.UTF_8));
        script.toFile().setExecutable(true);
        ProcessBuilder builder=new ProcessBuilder("sh","-c",ProcessScanner.COMMAND);builder.environment().put("PATH",dir+File.pathSeparator+System.getenv("PATH"));builder.environment().put("FLASHLAB_SCAN_TEST_INPUT",input.toString());
        Process peer=builder.start();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;
        try(InputStream stream=peer.getInputStream()){while((n=stream.read(buffer))!=-1)out.write(buffer,0,n);}
        ManagerChecks.equal(peer.waitFor(),0,"compact shell scan exit");ManagerChecks.check(Files.size(input)>1000000,"regression fixture exceeds old dump limit");ManagerChecks.check(out.size()<AdbSession.OUTPUT_LIMIT,"vehicle filtering keeps output within bounded buffer");
        BackgroundProcesses compact=ProcessScanner.parse(new ShellResult(out.toString("UTF-8"),0),28);
        ManagerChecks.equal(compact.background.size(),250,"all active media packages survive compact filtering");ManagerChecks.check(compact.complete,"all compact process records verified");
        Files.write(script,"#!/bin/sh\necho 'Permission Denial: blocked'\nexit 13\n".getBytes(StandardCharsets.UTF_8));
        peer=builder.start();out=new ByteArrayOutputStream();try(InputStream stream=peer.getInputStream()){while((n=stream.read(buffer))!=-1)out.write(buffer,0,n);}peer.waitFor();
        final ShellResult denied=new ShellResult(out.toString("UTF-8"),0);
        ManagerChecks.fails(()->ProcessScanner.parse(denied,28),"grep success cannot hide dumpsys failure");
        Files.delete(script);Files.delete(input);Files.delete(dir);
    }
    public static void main(String[] args)throws Exception {
        repeatedStreams();recovery();retention();compactLargeDump();System.out.println("PASS: "+ManagerChecks.cases+" repeated-refresh, reconnect, retention and compact vehicle-scan checks");
    }
}
