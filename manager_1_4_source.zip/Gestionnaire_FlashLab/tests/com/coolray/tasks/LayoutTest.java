package com.coolray.tasks;
import org.junit.*;import org.junit.runner.RunWith;import org.robolectric.*;import org.robolectric.annotation.*;import org.robolectric.android.controller.*;import org.robolectric.util.ReflectionHelpers;import android.app.*;import android.content.*;import android.view.*;import android.widget.*;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,manifest="AndroidManifest.xml",resourceDir="res",packageName="com.coolray.tasks",application=Application.class)
@LooperMode(LooperMode.Mode.PAUSED)
public class LayoutTest {
 @Test @Config(qualifiers="w390dp-h844dp-port-mdpi") public void narrowPhoneSetupFits()throws Exception{layout(390,844);}
 @Test @Config(qualifiers="w1024dp-h600dp-land-mdpi") public void carSetupFits()throws Exception{layout(1024,600);}
 void layout(int w,int h)throws Exception{ActivityController<TaskActivity> ctl=Robolectric.buildActivity(TaskActivity.class).create();try{TaskActivity a=ctl.get();View content=a.findViewById(android.R.id.content);content.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY));content.layout(0,0,w,h);Button setup=ReflectionHelpers.getField(a,"setupButton");Assert.assertEquals(View.VISIBLE,setup.getVisibility());Assert.assertTrue(setup.getWidth()>=92);Assert.assertTrue(setup.getHeight()>=48);int[] loc=new int[2];setup.getLocationInWindow(loc);Assert.assertTrue(loc[0]>=0&&loc[0]+setup.getWidth()<=w);Assert.assertTrue(loc[1]>=0&&loc[1]+setup.getHeight()<=h);}finally{ctl.destroy();}}
}
