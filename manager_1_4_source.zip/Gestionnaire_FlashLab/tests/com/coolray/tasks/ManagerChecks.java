package com.coolray.tasks;

import com.cgutman.adblib.AdbCrypto;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.file.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

public class ManagerChecks {
    static int cases;
    static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);cases++;}
    static void equal(Object actual,Object expected,String name){check(Objects.equals(actual,expected),name+": "+actual+" != "+expected);}
    interface Checked {void run()throws Exception;}
    static void fails(Checked call,String name)throws Exception{try{call.run();}catch(Exception expected){cases++;return;}throw new AssertionError(name);}
    static Set<String> strings(String... s){return new HashSet<>(Arrays.asList(s));}
    static String protection(String pkg,int uid,boolean system,boolean persistent,Set<Integer> uids,Set<String> homes,Set<String> keys){return StopPolicy.hardProtection(pkg,uid,system,persistent,"com.coolray.tasks",uids,homes,keys);}
    static class Env implements StopController.Environment {
        StopController.State state=new StopController.State(false,false);
        boolean force,cleanup=true,confirmed;int forces,requests,inspections,checks;boolean fail;
        public StopController.State inspect(String p){inspections++;return state;}
        public boolean forceAvailable(){return force;}
        public void force(String p)throws Exception{forces++;if(fail)throw new IOException("Denied");}
        public boolean stopped(String p){checks++;return confirmed;}
        public void pause(){}
        public boolean cleanupSupported(){return cleanup;}
        public void cleanup(String p)throws Exception{requests++;if(fail)throw new SecurityException("Denied");}
    }
    static void policy()throws Exception {
        Set<Integer> none=new HashSet<>();Set<String> empty=new HashSet<>();
        equal(protection("com.spotify.music",10123,false,false,none,empty,empty),null,"ordinary app eligible");
        check(protection("com.vendor.system",10123,true,false,none,empty,empty)!=null,"system app protected");
        check(protection("com.vendor.persistent",10123,false,true,none,empty,empty)!=null,"persistent app protected");
        check(protection("com.vendor.service",9999,false,false,none,empty,empty)!=null,"reserved UID protected");
        check(protection("com.vendor.service",109999,false,false,none,empty,empty)!=null,"secondary user reserved UID protected");
        check(protection("com.coolray.tasks",10123,false,false,none,empty,empty)!=null,"manager protected");
        for(String pkg:new String[]{"com.flyme.auto.launcher","com.ecarx.car","ecarx.power.service","com.geely.control","com.coolray.vehicle","com.google.android.gms"})check(protection(pkg,10123,false,false,none,empty,empty)!=null,"vehicle/core protected: "+pkg);
        check(protection("third.party.home",10123,false,false,none,strings("third.party.home"),empty)!=null,"third party launcher protected");
        check(protection("third.party.keyboard",10123,false,false,none,empty,strings("third.party.keyboard"))!=null,"third party keyboard protected");
        check(protection("com.shared.app",10123,false,false,new HashSet<>(Arrays.asList(10123)),empty,empty)!=null,"shared essential UID protected");
        for(String bad:new String[]{"com.app;reboot","com.app\nreboot","com.app$(id)","com..app","../system","com.app/name","com.app'",""}){check(!StopPolicy.validPackage(bad),"reject shell/metachar target");fails(()->StopPolicy.forceCommand(bad,0),"no unsafe command");}
        equal(StopPolicy.forceCommand("com.spotify.music",10),"am force-stop --user 10 com.spotify.music","user-scoped command");
        fails(()->StopPolicy.forceCommand("com.spotify.music",-1),"reject invalid user");
    }
    static void stopping()throws Exception {
        String pkg="com.example.app";Env e=new Env();
        equal(StopController.run(pkg,e),"REQUESTED","Android cleanup is only requested");equal(e.requests,1,"one cleanup");equal(e.forces,0,"no privileged action in standard mode");
        e=new Env();e.state=new StopController.State(true,false);e.force=true;equal(StopController.run(pkg,e),"PROTECTED","user protection checked fresh");equal(e.forces+e.requests,0,"protected app never stopped");
        e=new Env();e.state=new StopController.State(false,true);equal(StopController.run(pkg,e),"ALREADY","already stopped skipped");equal(e.forces+e.requests,0,"no repeat stopping");
        e=new Env();e.state=new StopController.State(false,false,false);e.force=true;equal(StopController.run(pkg,e),"NOT_BACKGROUND","foreground or inactive target skipped");equal(e.forces+e.requests,0,"no action after background state changes");
        e=new Env();e.state=null;equal(StopController.run(pkg,e),"ABSENT","uninstalled target skipped");
        e=new Env();e.force=true;e.confirmed=true;equal(StopController.run(pkg,e),"CONFIRMED","confirmed only after package state");equal(e.requests,0,"no fallback cleanup after force");
        e=new Env();e.force=true;equal(StopController.run(pkg,e),"UNVERIFIED","zero command exit alone is not confirmation");equal(e.checks,3,"bounded verification");
        e=new Env();e.cleanup=false;equal(StopController.run(pkg,e),"LIMITED","Android 14 standard limitation");equal(e.requests,0,"no forbidden other-app cleanup");
        final Env denied=new Env();denied.force=true;denied.fail=true;fails(()->StopController.run(pkg,denied),"privileged denial propagates");equal(denied.requests,0,"no silent downgrade after force failure");
        final Env invalid=new Env();fails(()->StopController.run("com.x;id",invalid),"invalid target rejected before environment");equal(invalid.inspections,0,"invalid target not inspected or executed");
    }
    static void shellResults()throws Exception {
        equal(ShellResult.parse("hello\n"+ShellResult.MARKER+"0\n").exit,0,"ADB exit marker");
        equal(ShellResult.parse("error\n"+ShellResult.MARKER+"13\n").exit,13,"ADB nonzero exit");
        equal(ShellResult.parse("hello").exit,-1,"missing exit marker not success");
        equal(ShellResult.parse("hello\n"+ShellResult.MARKER+"0\nextra").exit,-1,"trailing invalid output not success");
        check(new ShellResult("uid=2000(shell) gid=2000",0).privilegedIdentity(),"shell identity accepted");
        check(new ShellResult("uid=0(root)",0).privilegedIdentity(),"root identity accepted");
        check(!new ShellResult("uid=20000(app)",0).privilegedIdentity(),"app identity not privileged");
        check(!new ShellResult("uid=0(root)",1).privilegedIdentity(),"failed identity not accepted");
        RootShell shell=new RootShell("sh");ShellResult actual=shell.run(ShellResult.wrap("printf bonjour"),2000);
        equal(ShellResult.parse(actual.output).output,"bonjour","actual POSIX wrapper output");equal(ShellResult.parse(actual.output).exit,0,"actual POSIX wrapper exit");
        equal(shell.run("printf non; exit 7",2000).exit,7,"root process exit preserved");
    }
    interface Server {void serve(Socket socket)throws Exception;}
    interface Client {void run(AdbSession session)throws Exception;}
    static class Packet {int cmd,a,b;byte[] data;}
    static Packet read(InputStream in)throws Exception {
        DataInputStream input=new DataInputStream(in);byte[] header=new byte[24];input.readFully(header);ByteBuffer b=ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN);Packet p=new Packet();p.cmd=b.getInt();p.a=b.getInt();p.b=b.getInt();int length=b.getInt(),sum=b.getInt(),magic=b.getInt();
        if(length<0||length>1048576||magic!=(p.cmd^-1))throw new IOException("Test peer packet");p.data=new byte[length];input.readFully(p.data);int checksum=0;for(byte v:p.data)checksum+=v&255;if(sum!=checksum)throw new IOException("Test checksum");return p;
    }
    static void send(Socket s,int command,int a,int b,byte[] data)throws IOException {
        int sum=0;for(byte value:data)sum+=value&255;ByteBuffer packet=ByteBuffer.allocate(24+data.length).order(ByteOrder.LITTLE_ENDIAN);packet.putInt(command).putInt(a).putInt(b).putInt(data.length).putInt(sum).putInt(~command).put(data);s.getOutputStream().write(packet.array());s.getOutputStream().flush();
    }
    static void connection(Server server,Client client,AdbCrypto crypto)throws Exception {
        ServerSocket listener=new ServerSocket(0,1,InetAddress.getByName("127.0.0.1"));AtomicReference<Throwable> error=new AtomicReference<>();
        Thread thread=new Thread(()->{try(Socket s=listener.accept()){s.setSoTimeout(3000);server.serve(s);}catch(Throwable e){error.set(e);}},"ADB-test-server");thread.setDaemon(true);thread.start();
        try(Socket socket=new Socket("127.0.0.1",listener.getLocalPort());AdbSession session=new AdbSession(socket,crypto)){client.run(session);}
        finally{listener.close();thread.join(3500);}
        if(thread.isAlive())throw new AssertionError("Leaked test peer");if(error.get()!=null)throw new AssertionError("Test server",error.get());
    }
    static void adb()throws Exception {
        AdbCrypto crypto=AdbCrypto.generateAdbKeyPair(bytes->Base64.getEncoder().encodeToString(bytes));
        Path directory=Files.createTempDirectory("flash-manager-test-");File privateKey=directory.resolve("private").toFile(),publicKey=directory.resolve("public").toFile();crypto.saveAdbKeyPair(privateKey,publicKey);
        PublicKey publicRsa=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Files.readAllBytes(publicKey.toPath())));
        byte[] token=new byte[20];new SecureRandom().nextBytes(token);
        byte[] digestInfo={0x30,0x21,0x30,0x09,0x06,0x05,0x2b,0x0e,0x03,0x02,0x1a,0x05,0x00,0x04,0x14};
        connection(s->{
            Packet connect=read(s.getInputStream());equal(connect.cmd,0x4e584e43,"wire CNXN command");equal(connect.a,0x01000000,"classic checksum protocol");check(new String(connect.data,"UTF-8").equals("host::\0"),"host banner");
            send(s,AdbSession.AUTH,1,0,token);Packet signature=read(s.getInputStream());equal(signature.a,2,"AUTH signature type");Signature verifier=Signature.getInstance("NONEwithRSA");verifier.initVerify(publicRsa);verifier.update(digestInfo);verifier.update(token);check(verifier.verify(signature.data),"valid Android ADB RSA token signature");
            send(s,AdbSession.CNXN,0x01000000,4096,"device::\0".getBytes("UTF-8"));
            Packet open=read(s.getInputStream());equal(open.cmd,AdbSession.OPEN,"shell OPEN");String service=new String(open.data,"UTF-8");check(service.startsWith("shell:id; ")&&service.endsWith("\0"),"bounded legacy shell service");
            send(s,AdbSession.OKAY,17,open.a,new byte[0]);send(s,AdbSession.WRTE,17,open.a,("uid=2000(shell)\n"+ShellResult.MARKER+"0\n").getBytes("UTF-8"));equal(read(s.getInputStream()).cmd,AdbSession.OKAY,"write acknowledged");send(s,AdbSession.CLSE,17,open.a,new byte[0]);
        },c->{c.connect(false,2500);check(c.shell("id",2500).privilegedIdentity(),"authenticated shell round trip");},crypto);
        connection(s->{read(s.getInputStream());send(s,AdbSession.AUTH,1,0,token);read(s.getInputStream());send(s,AdbSession.AUTH,1,0,token);equal(s.getInputStream().read(),-1,"automatic reconnect sends no unapproved public key");},c->fails(()->c.connect(false,2000),"unapproved key refused without prompt"),crypto);
        connection(s->{read(s.getInputStream());send(s,AdbSession.AUTH,1,0,token);read(s.getInputStream());send(s,AdbSession.AUTH,1,0,token);Packet publication=read(s.getInputStream());equal(publication.a,3,"explicit authorization sends public key");check(publication.data[publication.data.length-1]==0,"NUL terminated ADB key");send(s,AdbSession.CNXN,0x01000000,4096,new byte[0]);},c->c.connect(true,2000),crypto);
        connection(s->{read(s.getInputStream());byte[] invalid=ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).putInt(AdbSession.CNXN).putInt(0).putInt(0).putInt(Integer.MAX_VALUE).putInt(0).putInt(~AdbSession.CNXN).array();s.getOutputStream().write(invalid);},c->fails(()->c.connect(false,1000),"oversized packet rejected before allocation"),crypto);
        connection(s->{read(s.getInputStream());byte[] invalid=AdbSession.encode(AdbSession.CNXN,0,0,new byte[]{1});invalid[16]=99;s.getOutputStream().write(invalid);},c->fails(()->c.connect(false,1000),"bad checksum rejected"),crypto);
        connection(s->{read(s.getInputStream());byte[] bytes=AdbSession.encode(AdbSession.CNXN,0,0,new byte[0]);for(int i=0;i<bytes.length;i++){try{s.getOutputStream().write(bytes,i,1);s.getOutputStream().flush();Thread.sleep(30);}catch(IOException closed){break;}}},c->{long start=System.nanoTime();fails(()->c.connect(false,160),"trickled header respects total deadline");check((System.nanoTime()-start)<1000000000L,"deadline bounded");},crypto);
        Files.delete(privateKey.toPath());Files.delete(publicKey.toPath());Files.delete(directory);
    }
    static String process(String name,String state,String packages){
        return "  *APP* UID 10123 ProcessRecord{ab12 2345:"+name+"/u0a123}\n    packageList={"+packages+"}\n    curProcState="+state+" setProcState="+state+"\n";
    }
    static void background(){
        equal(BackgroundProcesses.importance(100),BackgroundProcesses.FOREGROUND,"foreground UI excluded");
        equal(BackgroundProcesses.importance(200),BackgroundProcesses.FOREGROUND,"visible UI excluded");
        for(int n:new int[]{125,130,230,300})equal(BackgroundProcesses.importance(n),BackgroundProcesses.BACKGROUND,"active background importance "+n);
        for(int n:new int[]{325,350,400,1000})equal(BackgroundProcesses.importance(n),BackgroundProcesses.INACTIVE,"inactive importance "+n);
        equal(BackgroundProcesses.importance(50),BackgroundProcesses.UNKNOWN,"unknown importance excluded");
        for(int n=3;n<=10;n++)equal(BackgroundProcesses.procState(""+n,28),BackgroundProcesses.BACKGROUND,"Android 9 active process state "+n);
        for(int n=11;n<=19;n++)equal(BackgroundProcesses.procState(""+n,28),BackgroundProcesses.INACTIVE,"Android 9 inactive state "+n);
        equal(BackgroundProcesses.procState("2",28),BackgroundProcesses.FOREGROUND,"Android 9 top");
        equal(BackgroundProcesses.procState("9",35),BackgroundProcesses.UNKNOWN,"no assumed numeric layout on other versions");
        equal(BackgroundProcesses.procState("9999999999999999999999",28),BackgroundProcesses.UNKNOWN,"malformed number bounded");
        equal(BackgroundProcesses.procState("PROCESS_STATE_SERVICE",35),BackgroundProcesses.BACKGROUND,"named state supported");
        String dump=process("com.music.player:playback","3","com.music.player")+process("com.maps.app","2","com.maps.app")+process("com.cached.app","18","com.cached.app")+process("com.shared.process","9","com.shared.one, com.shared.two");
        BackgroundProcesses result=BackgroundProcesses.parse(dump,28);
        check(result.complete,"all records classified");equal(result.classified,4,"four process records classified");
        check(result.contains("com.music.player"),"service process suffix resolved");
        check(!result.contains("com.maps.app"),"foreground hidden");check(!result.contains("com.cached.app"),"cached hidden");
        check(result.contains("com.shared.one")&&result.contains("com.shared.two"),"packageList used for shared process");
        check(!result.contains("com.installed.only"),"installed alone never evidence");
        result=BackgroundProcesses.parse(process("com.same.app:worker","9","com.same.app")+process("com.same.app","2","com.same.app"),28);
        check(!result.contains("com.same.app"),"foreground wins across processes");
        result=BackgroundProcesses.parse(process("com.same.app","2","com.same.app")+process("com.same.app:worker","9","com.same.app"),28);
        check(!result.contains("com.same.app"),"foreground wins independent of order");
        BackgroundProcesses foreground=new BackgroundProcesses();foreground.add("com.shared.one",BackgroundProcesses.FOREGROUND);
        result=BackgroundProcesses.parse(dump,28);result.merge(foreground);check(!result.contains("com.shared.one"),"framework foreground evidence overrides privileged background");
        result=BackgroundProcesses.parse(process("com.known.app","SVC","com.known.app")+process("com.unknown.app","NEW_STATE","com.unknown.app"),35);
        check(result.contains("com.known.app"),"known textual background retained");check(!result.complete,"unknown state marked partial");check(!result.contains("com.unknown.app"),"unknown state never guessed");
        for(String invalid:new String[]{"Permission Denial: not allowed", "Permission denied", "", "USER PID NAME\n 10123 45 com.app"}){
            result=BackgroundProcesses.parse(invalid,28);check(result.background.isEmpty()&&!result.complete,"denied, empty or plain ps never complete evidence");
        }
        result=BackgroundProcesses.parse(process("com.cached.app","18","com.cached.app"),28);check(result.complete&&result.background.isEmpty(),"verified empty list differs from restricted detection");
    }
    public static void main(String[] args)throws Exception {
        policy();stopping();background();shellResults();adb();System.out.println("PASS: "+cases+" background-state, app protection, stop-result, shell and authenticated ADB checks");
    }
}
