FLASHLAB GESTIONNAIRE 1.4 — ACCÈS SUR LES NOUVELLES VOITURES
Heithem FlashLab · 0779 29 15 63

Installer FlashLab_Gestionnaire_1.4_Android9.apk par-dessus la version actuelle.
Même package com.coolray.tasks, même signature propriétaire, versionCode5.
Ne pas désinstaller : les protections, le choix d’accès et la clé ADB locale
restent conservés. Le bouton Gestionnaire du widget RAM reste compatible.

PREMIÈRE UTILISATION SUR UNE NOUVELLE VOITURE
Le choix automatique utilise l’accès système si les permissions de lecture et
d’arrêt sont réellement accordées. Sinon il essaie ADB local sur127.0.0.1:5555.
Il ne demande jamais root sans votre choix explicite.

Si l’accès manque, l’écran indique « Accès à configurer » et propose
« Activer l’accès aux applications ». Appuyer dessus et accepter la demande
Android si elle apparaît. Chaque voiture possède sa propre autorisation :
celle de votre voiture ne donne aucun droit sur celle d’un client.
Après autorisation, la clé de cette installation est réutilisée et les
reconnexions sont automatiques. Une simple mise à jour ne demande pas de
repartir de zéro. Un ancien choix « Nettoyage Android uniquement » reste
respecté ; utiliser le nouveau bouton pour passer à l’accès complet.

SI LE MESSAGE DIT QUE LE SERVICE ADB LOCAL NE RÉPOND PAS
Le réseau ADB n’est pas activé ou le service est inaccessible. Ce n’est pas
une permission qu’un APK normal peut s’accorder. Le flasheur doit préparer
cet accès une fois sur la voiture concernée, après le flash.
Sur un ordinateur ADB déjà autorisé, repérer LE BON numéro de série :
 adb devices -l
Puis, uniquement pour la tablette de ce client :
 adb -s NUMERO_DE_SERIE tcpip 5555
La connexion USB peut se couper à cette étape. Ouvrir ensuite Gestionnaire
sur la tablette, appuyer sur Activer l’accès et accepter la demande Android.
Sous PowerShell si adb.exe est dans le dossier courant, utiliser .\adb.exe.
Ne pas désactiver l’authentification ADB. La préparation du firmware reste
nécessaire si celui-ci désactive le service réseau à chaque redémarrage.
Cette version ne prétend pas corriger ce réglage de firmware depuis un APK.
Root reste un choix explicite dans Accès avancé si déjà installé/autorisé.

CORRECTIONS
- Une nouvelle installation ne mémorise plus silencieusement le mode Android
  limité comme s’il s’agissait d’une configuration complète.
- Détection automatique du système ou d’un ADB local déjà disponible/autorisé.
- Bouton d’activation direct, sans devoir parcourir plusieurs menus.
- Messages distincts : autorisation manquante, service ADB absent, connexion
  interrompue, accès root/système refusé.
- Une liste vide sans accès n’est plus présentée comme une preuve qu’aucune
  application ne travaille en arrière-plan. Les arrêts restent suspendus si
  la lecture n’est pas vérifiée.
- Reprise espacée de30secondes en cas de connexion indisponible ; pas de
  nouvelle publication de clé ni de demande root pendant ces essais passifs.

Les protections du lanceur, du clavier, des services système et des choix
utilisateur sont conservées. Les applications simplement installées ne sont
pas ajoutées artificiellement à la liste.

VÉRIFICATION
322contrôles historiques réussis (authentification ADB, flux successifs,
reconnexion, états de processus, protections et résultats d’arrêt).
11tests Android9/Robolectric réussis, dont9sur l’accès frais/système/refus,
et2sur la disposition téléphone/tablette. Signature propriétaire, version,
alignement et intégrité APK vérifiés. Pas d’essai physique sur la voiture
client ; vérifier accès, actualisations et arrêt d’une application non protégée.


RECONSTRUCTION
Utiliser build.py --help, les outils Android SDK28/BuildTools35 et ECJ3.38.0.
La clé propriétaire historique doit être fournie séparément. Aucune clé privée
ni identité ADB réelle n’est incluse dans les sources.
