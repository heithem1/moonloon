# Gestionnaire FlashLab 1.1

Application Android 9 en français, noire et or, créée pour le bouton Gestionnaire
du widget RAM du lanceur Coolray fourni par le propriétaire.

Composant public : `com.coolray.tasks/com.coolray.tasks.TaskActivity`.
Cette identité correspond exactement à `DashMemoryWidget.openTasks()` du lanceur.
L’installation de cette application suffit pour fournir ce composant ; aucun
remplacement du lanceur n’est inclus.

Fonctions : RAM disponible réelle, recherche, applications détectées, arrêt
individuel ou collectif, protections persistantes, accès à la fiche Android.
Le lanceur, les claviers, UID essentiels et applications système sont toujours
exclus des arrêts. Flash Connect, Gear, Store, Booster, Maps et Waze sont protégés
par défaut ; l’utilisateur peut retirer ces protections facultatives.

## Modes d’arrêt

Le mode Android utilise `ActivityManager.killBackgroundProcesses` sous Android
9–13 : il s’agit d’une demande de nettoyage, avec redémarrage possible. À partir
d’Android 14, l’application n’utilise pas cette API sur les autres packages.

Un véritable arrêt forcé nécessite une autorisation existante : permission
système `FORCE_STOP_PACKAGES`, accès root accordé, ou ADB local déjà activé sur
127.0.0.1:5555 et explicitement autorisé par le propriétaire du véhicule.
L’application n’active pas le débogage réseau, ne modifie pas SELinux, n’installe
pas root et n’utilise aucune clé partagée. Sa propre clé ADB est générée dans
son stockage privé non sauvegardé ; elle n’est jamais incluse dans les sources.
La publication de cette clé au serveur ADB n’a lieu qu’après le choix explicite
de l’option d’autorisation dans l’interface. Les reconnexions ordinaires envoient
uniquement une signature de challenge avec une clé déjà autorisée.

Chaque cible est vérifiée à nouveau juste avant l’arrêt. Un code de sortie nul
ne suffit pas : l’interface affiche « Arrêt forcé confirmé » uniquement après
lecture de `ApplicationInfo.FLAG_STOPPED`. Une perte d’accès avancé interrompt
le lot au lieu de le convertir silencieusement en nettoyage Android.

## Construction

Java 17, Eclipse ECJ 3.33, Android build-tools 35.0.0 et plateforme API 28.
Les outils et le fichier de signature doivent être fournis localement :

```sh
python3 build.py --build-tools /chemin/build-tools/35.0.0 \
  --android-jar /chemin/platforms/android-28/android.jar \
  --ecj /chemin/ecj.jar --keystore /chemin/flashlab-owner.p12 \
  --password-file /chemin/password.txt --alias flashlab \
  --output /chemin/Gestionnaire_FlashLab_1.1_Android9.apk
```

Aucune clé de signature n’est distribuée avec ces sources. Conserver le même
certificat et augmenter versionCode pour les futures mises à jour.

## Dépendances

Les deux fichiers de `vendor/com/cgutman/adblib` proviennent de Cameron Gutman,
AdbLib, révision d6937951eb98557c76ee2081e383d50886ce109a, sous licence Apache 2.0.
La licence est conservée dans assets/licenses. Le client ADB borné de cette
application est distinct du client asynchrone amont et n’ouvre qu’un flux à la fois.

Copyright 2026 Heithem FlashLab pour les fichiers propres au projet. Tous droits
réservés, hors dépendances et éléments soumis à leurs licences respectives.
