package com.coolray.tasks;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Base64;
import com.cgutman.adblib.AdbBase64;
import com.cgutman.adblib.AdbCrypto;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

/** All calls run on the activity's single worker, never on the UI thread. */
public final class AccessEngine {
    public enum Mode { ANDROID,SYSTEM,ADB,ROOT }
    private final Context context;
    private final SharedPreferences prefs;
    private final RootShell root=new RootShell();
    private volatile AdbSession adb;
    private Mode mode=Mode.ANDROID;
    public String message="Nettoyage Android disponible";
    public AccessEngine(Context context){this.context=context.getApplicationContext();prefs=context.getSharedPreferences("flash_manager_access",0);}
    public Mode mode(){return mode;}
    public boolean forceAvailable(){return mode!=Mode.ANDROID;}
    public void configure(Mode requested,boolean explicit)throws Exception {
        disconnect();mode=Mode.ANDROID;
        if(requested==Mode.ANDROID){prefs.edit().putString("mode","ANDROID").apply();message="Nettoyage Android disponible";return;}
        if(context.checkSelfPermission("android.permission.FORCE_STOP_PACKAGES")==PackageManager.PERMISSION_GRANTED){mode=Mode.SYSTEM;message="Arrêt forcé autorisé par le système";return;}
        if(requested==Mode.ROOT){
            ShellResult id=root.run("id",explicit?15000:4000);
            if(id.exit!=0||!id.output.matches("(?s).*\\buid=0\\b.*"))throw new SecurityException("Root not granted");
            mode=Mode.ROOT;message="Arrêt forcé disponible · accès root autorisé";
        }else if(requested==Mode.ADB){
            File dir=new File(context.getNoBackupFilesDir(),"adb");
            if(!dir.isDirectory()&&!dir.mkdirs())throw new java.io.IOException("Key directory");
            File privateKey=new File(dir,"identity.private"),publicKey=new File(dir,"identity.public");
            AdbBase64 base64=data->Base64.encodeToString(data,Base64.NO_WRAP);
            AdbCrypto crypto;
            try{crypto=AdbCrypto.loadAdbKeyPair(base64,privateKey,publicKey);}
            catch(Exception absent){
                crypto=AdbCrypto.generateAdbKeyPair(base64);crypto.saveAdbKeyPair(privateKey,publicKey);
                privateKey.setReadable(false,false);privateKey.setWritable(false,false);
                privateKey.setReadable(true,true);privateKey.setWritable(true,true);
            }
            Socket socket=new Socket();
            try {
                socket.connect(new InetSocketAddress("127.0.0.1",5555),1500);
                AdbSession session=new AdbSession(socket,crypto);adb=session;
                session.connect(explicit,explicit?30000:3000);
                ShellResult id=session.shell("id",4000);
                if(!id.privilegedIdentity())throw new SecurityException("ADB shell not privileged");
                mode=Mode.ADB;message="Arrêt forcé disponible · ADB local autorisé";
            }catch(Exception error){socket.close();adb=null;throw error;}
        }else throw new SecurityException("System permission unavailable");
        prefs.edit().putString("mode",requested.name()).apply();
    }
    public void refresh() {
        if(context.checkSelfPermission("android.permission.FORCE_STOP_PACKAGES")==PackageManager.PERMISSION_GRANTED){mode=Mode.SYSTEM;message="Arrêt forcé autorisé par le système";return;}
        Mode requested;
        try{requested=Mode.valueOf(prefs.getString("mode","ANDROID"));}catch(Exception ignored){requested=Mode.ANDROID;}
        if(mode==Mode.ADB&&adb!=null&&adb.isOpen())return;
        if(mode==Mode.ROOT&&requested==Mode.ROOT)return;
        try{configure(requested,false);}catch(Exception denied){mode=Mode.ANDROID;disconnect();message="Accès avancé indisponible · nettoyage Android uniquement";}
    }
    public ShellResult shell(String command,int timeout)throws Exception {
        if(mode==Mode.ADB&&adb!=null)return adb.shell(command,timeout);
        if(mode==Mode.ROOT)return root.run(command,timeout);
        throw new SecurityException("No shell access");
    }
    public Set<String> detectedPackages() {
        Set<String> found=new HashSet<>();
        ActivityManager am=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
        try{java.util.List<ActivityManager.RunningAppProcessInfo> running=am.getRunningAppProcesses();
            if(running!=null)for(ActivityManager.RunningAppProcessInfo p:running)if(p.pkgList!=null)java.util.Collections.addAll(found,p.pkgList);
        }catch(RuntimeException ignored){}
        if(mode==Mode.ADB||mode==Mode.ROOT)try{
            ShellResult ps=shell("ps -A",5000);
            if(ps.exit==0)for(String line:ps.output.split("\\r?\\n")){
                String[] parts=line.trim().split("\\s+");if(parts.length<2)continue;
                String name=parts[parts.length-1];int colon=name.indexOf(':');if(colon>=0)name=name.substring(0,colon);
                if(StopPolicy.validPackage(name))found.add(name);
            }
        }catch(Exception ignored){if(mode==Mode.ADB)invalidate();}
        return found;
    }
    public void force(String name)throws Exception {
        if(!StopPolicy.validPackage(name))throw new SecurityException("Invalid package");
        if(mode==Mode.SYSTEM){
            Object am=context.getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.class.getDeclaredMethod("forceStopPackage",String.class).invoke(am,name);
        }else{
            ShellResult result=shell(StopPolicy.forceCommand(name,android.os.Process.myUid()/100000),6000);
            if(result.exit!=0)throw new java.io.IOException("Force-stop denied");
        }
    }
    public void invalidate(){mode=Mode.ANDROID;disconnect();message="Accès avancé interrompu · réactivez-le pour forcer l’arrêt";}
    public void disconnect(){AdbSession session=adb;adb=null;if(session!=null)try{session.close();}catch(Exception ignored){}}
}
