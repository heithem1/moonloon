package com.coolray.tasks;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Exported entry point is intentionally the exact component called by the existing RAM widget. */
public final class TaskActivity extends Activity {
    private static final int GOLD=0xFFD8B45C,BG=0xFF080909,PANEL=0xFF111313,BORDER=0xFF3B3322,WHITE=0xFFF5F2E9,MUTED=0xFFAAA89F;
    private static final int GAP=12,CONTROL=48,RADIUS=16,ICON=44,SIDEBAR=230;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean cancelled=new AtomicBoolean();
    private final List<View> actions=new ArrayList<>();
    private final Map<String,String> lastResults=new HashMap<>();
    private AppRepository repository;
    private AccessEngine engine;
    private AppRepository.Snapshot snapshot;
    private LinearLayout rows;
    private TextView memoryValue,memoryDetail,modeValue,modeNote,feedback,count;
    private ProgressBar memoryBar,busyBar;
    private Button stopAll,cancelButton;
    private String query="";
    private int filter;
    private boolean busy,destroyed,resumed;
    private final Runnable memoryTick=new Runnable(){public void run(){if(resumed&&!destroyed){updateMemory();ui.postDelayed(this,5000);}}};

    @Override protected void attachBaseContext(Context context){
        Configuration c=new Configuration(context.getResources().getConfiguration());c.setLocale(Locale.FRENCH);c.setLayoutDirection(Locale.FRENCH);
        super.attachBaseContext(context.createConfigurationContext(c));
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        repository=new AppRepository(this);engine=new AccessEngine(this);buildLayout();
    }
    @Override protected void onResume(){super.onResume();resumed=true;ui.removeCallbacks(memoryTick);ui.post(memoryTick);refresh();}
    @Override protected void onPause(){resumed=false;ui.removeCallbacks(memoryTick);super.onPause();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);refresh();}
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);buildLayout();renderRows();updateMemory();updateMode();}
    @Override protected void onDestroy(){destroyed=true;cancelled.set(true);ui.removeCallbacksAndMessages(null);engine.disconnect();worker.shutdownNow();super.onDestroy();}

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout line(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String text,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);v.setFontFeatureSettings("tnum");if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable shape(int fill,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private LinearLayout.LayoutParams full(int height){return new LinearLayout.LayoutParams(-1,height<0?height:dp(height));}
    private LinearLayout.LayoutParams gap(){LinearLayout.LayoutParams p=full(-2);p.topMargin=dp(GAP);return p;}
    private Button button(String text,boolean filled,Runnable click){
        Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextSize(15);b.setTextColor(filled?BG:GOLD);b.setMinHeight(dp(CONTROL));b.setMinimumHeight(dp(CONTROL));b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(12),dp(4),dp(12),dp(4));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44D8B45C),shape(filled?GOLD:Color.TRANSPARENT,filled?0:BORDER,12),null));
        b.setOnClickListener(v->{if(!busy)click.run();});b.setEnabled(!busy);b.setAlpha(busy?.45f:1f);actions.add(b);return b;
    }
    private LinearLayout card(){LinearLayout c=column();c.setPadding(dp(16),dp(16),dp(16),dp(16));c.setBackground(shape(PANEL,BORDER,RADIUS));return c;}
    private void buildLayout(){
        actions.clear();LinearLayout root=column();root.setBackgroundColor(BG);root.setPadding(dp(16),dp(10),dp(16),dp(10));
        LinearLayout header=line();ImageView mark=new ImageView(this);mark.setImageResource(R.mipmap.ic_launcher);mark.setScaleType(ImageView.ScaleType.FIT_CENTER);header.addView(mark,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout title=column();title.setPadding(dp(12),0,dp(8),0);title.addView(label("FLASHLAB",12,GOLD,true));TextView heading=label("Gestionnaire",25,WHITE,true);heading.setSingleLine();heading.setEllipsize(TextUtils.TruncateAt.END);title.addView(heading);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));header.addView(button("Actualiser",false,this::refresh),new LinearLayout.LayoutParams(-2,dp(CONTROL)));root.addView(header,full(64));
        boolean landscape=getResources().getConfiguration().screenWidthDp>=600&&getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
        LinearLayout body=landscape?line():column();body.setGravity(Gravity.TOP);LinearLayout.LayoutParams bodyParams=full(0);bodyParams.weight=1;bodyParams.topMargin=dp(8);root.addView(body,bodyParams);
        LinearLayout summary=column();
        LinearLayout ram=card();ram.addView(label("RAM DISPONIBLE",12,MUTED,true));memoryValue=label("— Go",38,GOLD,true);ram.addView(memoryValue);memoryDetail=label("Lecture de la mémoire…",13,MUTED,false);ram.addView(memoryDetail);
        memoryBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);memoryBar.setMax(100);memoryBar.setProgressTintList(ColorStateList.valueOf(GOLD));memoryBar.setProgressBackgroundTintList(ColorStateList.valueOf(BORDER));LinearLayout.LayoutParams bar=full(5);bar.topMargin=dp(12);ram.addView(memoryBar,bar);summary.addView(ram);
        modeValue=label("Nettoyage Android",16,GOLD,true);modeNote=label("",13,MUTED,false);
        LinearLayout access=card();access.addView(modeValue);LinearLayout.LayoutParams note=full(-2);note.topMargin=dp(6);access.addView(modeNote,note);access.addView(button("Accès avancé",false,this::accessDialog),gap());
        stopAll=button("Tout arrêter",true,this::confirmAll);summary.addView(stopAll,gap());
        TextView keep=label("Hors applications protégées",12,MUTED,false);keep.setGravity(Gravity.CENTER);LinearLayout.LayoutParams keepParams=full(-2);keepParams.topMargin=dp(5);summary.addView(keep,keepParams);
        summary.addView(access,gap());TextView about=label("Heithem FlashLab  ·  À propos",12,MUTED,false);about.setPadding(0,dp(14),0,dp(8));about.setOnClickListener(v->about());summary.addView(about);
        if(landscape){ScrollView summaryScroll=new ScrollView(this);summaryScroll.setFillViewport(false);summaryScroll.addView(summary);LinearLayout.LayoutParams side=new LinearLayout.LayoutParams(dp(SIDEBAR),-1);side.setMarginEnd(dp(16));body.addView(summaryScroll,side);}
        else {
            // Keep both main actions visible on a narrow phone without horizontal scrolling.
            LinearLayout compact=line();compact.setGravity(Gravity.TOP);
            summary.removeAllViews();memoryValue.setTextSize(30);memoryDetail.setTextSize(11);ram.setPadding(dp(12),dp(12),dp(12),dp(12));compact.addView(ram,new LinearLayout.LayoutParams(0,dp(180),1));
            access.removeView(modeValue);modeValue.setTextSize(12);modeValue.setSingleLine();ram.addView(modeValue,gap());
            LinearLayout controls=column();controls.setPadding(dp(10),0,0,0);controls.addView(stopAll,full(CONTROL));controls.addView(button("Accès avancé",false,this::accessDialog),gap());controls.addView(about,full(-2));compact.addView(controls,new LinearLayout.LayoutParams(0,-2,1));body.addView(compact,full(183));
        }
        LinearLayout listing=column();LinearLayout.LayoutParams listingParams=landscape?new LinearLayout.LayoutParams(0,-1,1):new LinearLayout.LayoutParams(-1,0,1);body.addView(listing,listingParams);
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setTextSize(16);search.setHint("Rechercher une application…");search.setPadding(dp(14),0,dp(12),0);search.setBackground(shape(PANEL,BORDER,12));search.setText(query);listing.addView(search,full(CONTROL));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){query=s.toString();renderRows();}public void afterTextChanged(Editable e){}});
        HorizontalScrollView tabs=new HorizontalScrollView(this);tabs.setHorizontalScrollBarEnabled(false);LinearLayout filters=line();String[] labels={"Toutes","Détectées","Protégées"};
        for(int i=0;i<labels.length;i++){final int which=i;Button tab=button(labels[i],filter==i,()->{filter=which;buildLayout();renderRows();updateMode();updateMemory();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,dp(CONTROL));p.setMarginEnd(dp(8));filters.addView(tab,p);}tabs.addView(filters);LinearLayout.LayoutParams tabsParams=full(CONTROL);tabsParams.topMargin=dp(10);listing.addView(tabs,tabsParams);
        count=label("Chargement des applications…",12,MUTED,false);count.setPadding(0,dp(4),0,dp(8));listing.addView(count,full(-2));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);rows=column();scroll.addView(rows);LinearLayout.LayoutParams scrollParams=full(0);scrollParams.weight=1;listing.addView(scroll,scrollParams);
        busyBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);busyBar.setIndeterminate(true);busyBar.setIndeterminateTintList(ColorStateList.valueOf(GOLD));busyBar.setVisibility(busy?View.VISIBLE:View.GONE);root.addView(busyBar,full(3));
        LinearLayout bottom=line();feedback=label("Choisissez une application ou arrêtez toutes les applications non protégées.",13,MUTED,false);feedback.setPadding(0,dp(8),dp(8),0);bottom.addView(feedback,new LinearLayout.LayoutParams(0,-2,1));cancelButton=button("Annuler",false,()->{});cancelButton.setOnClickListener(v->{cancelled.set(true);engine.disconnect();feedback.setText("Annulation demandée. Les arrêts déjà effectués sont conservés.");});cancelButton.setVisibility(busy?View.VISIBLE:View.GONE);bottom.addView(cancelButton,new LinearLayout.LayoutParams(-2,dp(CONTROL)));root.addView(bottom,full(-2));
        setContentView(root);updateMode();updateMemory();renderRows();
    }
    private void updateMemory(){
        if(memoryValue==null)return;
        ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);
        int percent=m.totalMem<=0?0:(int)Math.min(100,m.availMem*100/m.totalMem);
        memoryValue.setText(String.format(Locale.FRANCE,"%.1f Go",m.availMem/1073741824.0));
        memoryDetail.setText(String.format(Locale.FRANCE,"sur %.1f Go · %d %% disponible",m.totalMem/1073741824.0,percent));memoryBar.setProgress(percent);
    }
    private void updateMode(){
        if(engine==null||modeValue==null)return;
        modeValue.setText(engine.forceAvailable()?"Arrêt forcé disponible":"Nettoyage Android");
        modeNote.setText(engine.forceAvailable()?engine.message:"Android peut relancer les applications nettoyées. L’accès avancé permet de forcer leur arrêt.");
    }
    private void setBusy(boolean value){
        busy=value;for(View v:actions){v.setEnabled(!value);v.setAlpha(value?.45f:1f);}busyBar.setVisibility(value?View.VISIBLE:View.GONE);cancelButton.setVisibility(value?View.VISIBLE:View.GONE);cancelButton.setEnabled(true);cancelButton.setAlpha(1);renderRows();
    }
    private void renderRows(){
        if(rows==null)return;rows.removeAllViews();
        if(snapshot==null)return;
        int shown=0,eligible=0;String needle=query.trim().toLowerCase(Locale.FRENCH);
        for(AppRepository.App app:snapshot.apps){
            if(!app.protectedApp()&&!app.stopped)eligible++;
            boolean include=filter==2?app.protectedApp():!app.system&&(filter!=1||app.detected);
            if(!include||!needle.isEmpty()&&!(app.name+" "+app.pkg).toLowerCase(Locale.FRENCH).contains(needle))continue;
            shown++;LinearLayout row=line();row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(shape(PANEL,app.protectedApp()?BORDER:0xFF272A26,RADIUS));
            ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);icon.setPadding(dp(2),dp(2),dp(2),dp(2));try{icon.setImageDrawable(getPackageManager().getApplicationIcon(app.pkg));}catch(Exception absent){icon.setImageResource(R.mipmap.ic_launcher);}icon.setContentDescription("Détails de "+app.name);icon.setOnClickListener(v->details(app));row.addView(icon,new LinearLayout.LayoutParams(dp(ICON),dp(ICON)));
            LinearLayout text=column();text.setPadding(dp(12),0,dp(10),0);TextView title=label(app.name,18,WHITE,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);title.setOnClickListener(v->details(app));text.addView(title);
            String state=lastResults.get(app.pkg);if(state==null)state=app.stopped?"À l’arrêt":app.detected?"Processus détecté":"Activité non déterminée";
            TextView status=label(state,12,MUTED,false);status.setMaxLines(2);text.addView(status);
            TextView protect=label(app.hardReason!=null?"Protégée · "+app.hardReason:app.protectedByUser?"✓ Protégée  ·  modifier":"Protéger cette application",12,GOLD,false);protect.setPadding(0,dp(7),0,dp(3));
            if(app.hardReason==null)protect.setOnClickListener(v->{if(!busy)toggleProtection(app);});text.addView(protect);
            row.addView(text,new LinearLayout.LayoutParams(0,-2,1));Button stop=button(app.stopped?"Arrêtée":"Arrêter",false,()->stopOne(app));actions.remove(stop);stop.setTextSize(14);stop.setEnabled(!busy&&!app.protectedApp()&&!app.stopped);stop.setAlpha(stop.isEnabled()?1f:.35f);row.addView(stop,new LinearLayout.LayoutParams(dp(92),dp(CONTROL)));
            LinearLayout.LayoutParams p=full(-2);p.bottomMargin=dp(10);rows.addView(row,p);
        }
        count.setText(shown+" application"+(shown==1?"":"s")+" · "+eligible+" à gérer hors protections");stopAll.setEnabled(!busy&&eligible>0);stopAll.setAlpha(stopAll.isEnabled()?1f:.4f);
        if(shown==0){TextView empty=label(filter==1?"Aucun autre processus détecté. Android peut limiter cette liste ; consultez Toutes pour gérer les applications installées.":"Aucune application ne correspond à cette sélection.",16,MUTED,false);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(24),dp(36),dp(24),dp(36));rows.addView(empty,full(-2));}
    }
    private void toggleProtection(AppRepository.App app){
        if(app.protectedByUser)new AlertDialog.Builder(this).setTitle("Retirer la protection ?").setMessage(app.name+" pourra alors être arrêtée, y compris avec Tout arrêter.").setNegativeButton("Annuler",null).setPositiveButton("Retirer",(d,w)->{repository.protect(app.pkg,false);app.protectedByUser=false;renderRows();}).show();
        else{repository.protect(app.pkg,true);app.protectedByUser=true;renderRows();}
    }
    private void details(AppRepository.App app){
        if(busy)return;
        String status=app.hardReason!=null?"Protection : "+app.hardReason:app.protectedByUser?"Protection activée":"Non protégée";
        new AlertDialog.Builder(this).setTitle(app.name).setMessage(status+"\n\n"+app.pkg+"\n\nSans accès avancé, Android autorise une demande de nettoyage des processus en arrière-plan. Les applications peuvent redémarrer.")
            .setNegativeButton("Fermer",null).setNeutralButton("Fiche Android",(d,w)->openSystemDetails(app.pkg)).setPositiveButton("Ouvrir",(d,w)->{
                Intent launch=getPackageManager().getLaunchIntentForPackage(app.pkg);if(launch!=null)try{startActivity(launch);}catch(RuntimeException denied){feedback.setText("Impossible d’ouvrir cette application.");}else feedback.setText("Cette application n’a pas d’écran de lancement.");
            }).show();
    }
    private void openSystemDetails(String pkg){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+pkg)));}catch(RuntimeException absent){feedback.setText("La fiche Android est indisponible sur cet appareil.");}}
    private void about(){new AlertDialog.Builder(this).setTitle("Gestionnaire FlashLab · 1.1").setMessage("Créé pour votre Coolray par Heithem FlashLab\n0779 29 15 63\n\nLe bouton Gestionnaire du widget RAM ouvre directement cette application.\n\nLe nettoyage Android est une demande, pas une garantie d’arrêt. L’arrêt forcé nécessite un accès système, root ou ADB local déjà autorisé. Aucune activation automatique du débogage.\n\nAucune publicité ni collecte de données. La connexion ADB reste sur cet appareil.\n\nInclut AdbCrypto et AdbBase64 de Cameron Gutman, licence Apache 2.0.").setPositiveButton("Fermer",null).show();}
    private void accessDialog(){
        if(busy)return;
        String[] choices={"ADB local · autoriser sur l’écran du véhicule","Root · si déjà installé sur le véhicule","Nettoyage Android uniquement"};
        new AlertDialog.Builder(this).setTitle("Choisir l’accès avancé").setMessage("ADB nécessite le débogage réseau déjà activé sur ce véhicule, port 5555. Acceptez sa demande d’autorisation si elle apparaît. Root nécessite une autorisation du gestionnaire root. Aucun réglage système n’est activé automatiquement.")
            .setPositiveButton("Choisir",(d,w)->new AlertDialog.Builder(this).setTitle("Méthode d’accès").setItems(choices,(dialog,which)->configure(which==0?AccessEngine.Mode.ADB:which==1?AccessEngine.Mode.ROOT:AccessEngine.Mode.ANDROID)).setNegativeButton("Annuler",null).show()).setNegativeButton("Annuler",null).show();
    }
    private void configure(AccessEngine.Mode mode){
        setBusy(true);cancelled.set(false);feedback.setText(mode==AccessEngine.Mode.ADB?"Connexion locale… Autorisez cet appareil dans la demande Android si elle apparaît.":"Vérification de l’accès…");
        worker.execute(()->{
            String message;
            try{engine.configure(mode,true);message=engine.message;}
            catch(Exception denied){engine.invalidate();message=mode==AccessEngine.Mode.ADB?"ADB local non autorisé ou indisponible. Activez le débogage réseau sur le véhicule et acceptez sa demande, puis réessayez. Le nettoyage Android reste disponible.":"Accès root non accordé ou absent. Le nettoyage Android reste disponible.";}
            final String text=message;AppRepository.Snapshot loaded=null;try{loaded=repository.load(engine.detectedPackages());}catch(RuntimeException ignored){}
            final AppRepository.Snapshot result=loaded;
            post(()->{if(result!=null)snapshot=result;setBusy(false);updateMode();feedback.setText(text);updateMemory();});
        });
    }
    private void refresh(){
        if(busy||destroyed)return;setBusy(true);cancelled.set(false);feedback.setText("Actualisation des applications…");
        worker.execute(()->{try{engine.refresh();AppRepository.Snapshot result=repository.load(engine.detectedPackages());post(()->{snapshot=result;setBusy(false);updateMode();updateMemory();feedback.setText("Liste actualisée. La détection peut être limitée par Android.");});}
            catch(Exception error){post(()->{setBusy(false);feedback.setText("Impossible de charger les applications. Réessayez avec Actualiser.");});}});
    }
    private void confirmAll(){
        if(snapshot==null)return;List<AppRepository.App> targets=new ArrayList<>();for(AppRepository.App app:snapshot.apps)if(!app.protectedApp()&&!app.stopped)targets.add(app);
        if(targets.isEmpty())return;
        String explanation=engine.forceAvailable()?"Les applications non protégées seront arrêtées. Vous pourrez les ouvrir à nouveau ensuite.":"Android recevra une demande de nettoyage pour les applications non protégées. Elles peuvent redémarrer ; ce mode ne garantit pas un arrêt forcé.";
        new AlertDialog.Builder(this).setTitle("Gérer "+targets.size()+" applications ?").setMessage(explanation+"\n\nLe lanceur, le clavier, les services système et les applications protégées sont exclus.").setNegativeButton("Annuler",null).setPositiveButton("Tout arrêter",(d,w)->runStops(targets)).show();
    }
    private void stopOne(AppRepository.App app){runStops(Collections.singletonList(app));}
    private void runStops(List<AppRepository.App> targets){
        setBusy(true);cancelled.set(false);feedback.setText("Traitement des applications…");
        worker.execute(()->{
            int confirmed=0,requested=0,unverified=0,failed=0,skipped=0;Map<String,String> updates=new HashMap<>();int index=0;boolean lostAccess=false;final boolean forceBatch=engine.forceAvailable();
            for(AppRepository.App app:targets){
                if(cancelled.get()||Thread.currentThread().isInterrupted())break;
                final String progress="Traitement "+(++index)+" / "+targets.size()+" · "+app.name;post(()->feedback.setText(progress));
                try{
                    String result=repository.stop(app,engine);
                    if(result.equals("CONFIRMED")){confirmed++;updates.put(app.pkg,"Arrêt forcé confirmé");}
                    else if(result.equals("REQUESTED")){requested++;updates.put(app.pkg,"Nettoyage demandé · redémarrage possible");}
                    else if(result.equals("UNVERIFIED")){unverified++;updates.put(app.pkg,"Commande acceptée · arrêt à vérifier");}
                    else if(result.equals("LIMITED")){failed++;updates.put(app.pkg,"Android limite l’arrêt · voir Fiche Android");}
                    else{skipped++;updates.put(app.pkg,result.equals("PROTECTED")?"Protection conservée":"Déjà à l’arrêt ou désinstallée");}
                }catch(Exception denied){failed++;updates.put(app.pkg,"Arrêt non confirmé · vérifier l’accès");engine.invalidate();if(forceBatch){lostAccess=true;break;}}
            }
            final String summary=(lostAccess?"Accès interrompu · ":cancelled.get()?"Annulé · ":"")+confirmed+" arrêts confirmés · "+requested+" nettoyages demandés · "+unverified+" à vérifier · "+failed+" échecs · "+skipped+" ignorées";
            AppRepository.Snapshot result=null;try{result=repository.load(engine.detectedPackages());}catch(RuntimeException ignored){}
            final AppRepository.Snapshot fresh=result;
            post(()->{lastResults.putAll(updates);if(fresh!=null)snapshot=fresh;setBusy(false);updateMode();updateMemory();feedback.setText(summary);});
        });
    }
    private void post(Runnable action){ui.post(()->{if(!destroyed)action.run();});}
}
